import express from "express";
import path from "path";
import cors from "cors";
import helmet from "helmet";
import { createServer as createViteServer } from "vite";
import db, { initDb } from "./src/lib/db.ts";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import multer from "multer";
import ExcelJS from "exceljs";
import PDFDocument from "pdfkit";

const PORT = 3000;
const JWT_SECRET = process.env.JWT_SECRET || "titan_gym_secure_secret";

async function startServer() {
  await initDb();
  
  // Auto-seed admin and plans if missing
  const userCount = await db("users").count("id as count").first();
  if (Number(userCount?.count) === 0) {
    console.log("Empty database detected. Seeding initial admin...");
    const hashedPassword = await bcrypt.hash("admin123", 10);
    await db("users").insert({
      name: "Admin User",
      email: "admin@titangym.com",
      password: hashedPassword,
      role: "admin"
    });
  }

  const planCount = await db("membership_plans").count("id as count").first();
  if (Number(planCount?.count) === 0) {
    await db("membership_plans").insert([
      { name: "Monthly Basic", price: 50, duration_months: 1 },
      { name: "Quarterly Pro", price: 135, duration_months: 3 },
      { name: "Annual Elite", price: 480, duration_months: 12 },
    ]);
    console.log("Membership plans seeded.");
  }

  const app = express();

  app.use(cors());
  app.use(helmet({
    contentSecurityPolicy: false, // For development and iframe compatibility
  }));
  app.use(express.json());

  // --- Auth Middleware ---
  const authenticateToken = (req: any, res: any, next: any) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (!token) return res.sendStatus(401);

    jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
      if (err) return res.sendStatus(403);
      req.user = user;
      next();
    });
  };

  // --- API Routes ---

  app.get("/api/health", async (req, res) => {
    const userCount = await db("users").count("id as count").first();
    res.json({ 
      status: "ok", 
      time: new Date().toISOString(),
      database: "connected",
      userCount: userCount?.count 
    });
  });

  // Auth
  app.post("/api/auth/login", async (req, res) => {
    const { email, password } = req.body;
    console.log(`Login attempt for: ${email}`);
    try {
      const user = await db("users").where({ email }).first();
      if (!user) {
        console.log(`User not found: ${email}`);
        return res.status(401).json({ error: "Invalid credentials" });
      }

      const isValid = await bcrypt.compare(password, user.password);
      if (!isValid) {
        console.log(`Invalid password for: ${email}`);
        return res.status(401).json({ error: "Invalid credentials" });
      }

      console.log(`Login successful: ${email}`);
      const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: "8h" });
      res.json({ token, user: { id: user.id, name: user.name, email: user.email, role: user.role } });
    } catch (err: any) {
      console.error("Login Error:", err);
      res.status(500).json({ error: "Login failed: " + err.message });
    }
  });

  // Seeds (Demo)
  app.post("/api/admin/seed", async (req, res) => {
    const count = await db("users").count("id as count").first();
    if (Number(count?.count) === 0) {
      const hashedPassword = await bcrypt.hash("admin123", 10);
      await db("users").insert({
        name: "Admin User",
        email: "admin@titangym.com",
        password: hashedPassword,
        role: "admin"
      });
      
      await db("membership_plans").insert([
        { name: "Monthly Basic", price: 50, duration_months: 1 },
        { name: "Quarterly Pro", price: 135, duration_months: 3 },
        { name: "Annual Elite", price: 480, duration_months: 12 },
      ]);

      const members = [
        { member_id: "M1001", name: "John Doe", email: "john@example.com", phone: "555-0101", is_active: true, plan_id: 1, membership_end: "2026-12-31" },
        { member_id: "M1002", name: "Jane Smith", email: "jane@example.com", phone: "555-0102", is_active: true, plan_id: 2, membership_end: "2026-08-15" },
        { member_id: "M1003", name: "Mike Tyson", email: "mike@example.com", phone: "555-0103", is_active: true, plan_id: 3, membership_end: "2027-01-01" },
        { member_id: "M1004", name: "Sarah Connor", email: "sarah@example.com", phone: "555-0104", is_active: false, plan_id: 1, membership_end: "2024-01-01" },
      ];

      const memberIds = await db("members").insert(members);

      // Add some sample attendance for the last 7 days
      const attendanceData = [];
      for (let i = 0; i < 7; i++) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        const dateString = date.toISOString().split('T')[0];
        
        // Random 5-15 checkins per day
        const dailyCount = Math.floor(Math.random() * 10) + 5;
        for (let j = 0; j < dailyCount; j++) {
           attendanceData.push({
             member_id: memberIds[0], // Use first member for dummy data
             date: dateString,
             check_in: dateString + " 10:00:00"
           });
        }
      }
      await db("attendance").insert(attendanceData);

      // Add sample payments
      await db("payments").insert([
        { member_id: memberIds[0], amount: 50, invoice_number: "INV-001" },
        { member_id: memberIds[1], amount: 135, invoice_number: "INV-002" },
        { member_id: memberIds[2], amount: 480, invoice_number: "INV-003" },
      ]);

      return res.json({ message: "Seed successful. Admin: admin@titangym.com / admin123" });
    }
    res.json({ message: "Database already seeded" });
  });

  // Members
  app.get("/api/members", authenticateToken, async (req, res) => {
    try {
      const members = await db("members")
        .leftJoin("membership_plans", "members.plan_id", "membership_plans.id")
        .leftJoin("trainers", "members.trainer_id", "trainers.id")
        .select(
          "members.*", 
          "membership_plans.name as plan_name",
          "trainers.name as trainer_name"
        );
      res.json(members);
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch members" });
    }
  });

  app.post("/api/members", authenticateToken, async (req, res) => {
    const { 
      name, father_name, cnic, address, whatsapp, email, phone, 
      plan_id, trainer_id, membership_start, membership_end, 
      member_id, height, weight, emergency_contact, notes 
    } = req.body;
    
    try {
      // Check for existing email if provided
      if (email) {
        const existingMember = await db("members").where({ email }).first();
        if (existingMember) {
          return res.status(400).json({ error: "Member with this email already exists" });
        }
      }

      // Generate sequential Member ID (M0001, M0002, etc) based on auto-increment ID
      const maxIdResult = await db("members").max("id as max").first();
      const nextSeq = (Number(maxIdResult?.max) || 0) + 1;
      const generatedId = `M${nextSeq.toString().padStart(4, '0')}`;

      const [id] = await db("members").insert({
        member_id: member_id || generatedId,
        name,
        father_name,
        cnic,
        address,
        whatsapp,
        email,
        phone,
        plan_id: plan_id ? parseInt(plan_id) : null,
        trainer_id: trainer_id ? parseInt(trainer_id) : null,
        membership_start,
        membership_end,
        height: height ? parseFloat(height) : null,
        weight: weight ? parseFloat(weight) : null,
        emergency_contact,
        notes,
        is_active: true,
        created_at: db.fn.now()
      });
      
      const newMember = await db("members").where({ id }).first();
      res.json(newMember);
    } catch (err: any) {
      console.error("Member creation error:", err);
      res.status(500).json({ error: "Failed to create member: " + err.message });
    }
  });

  // Plans
  app.get("/api/plans", authenticateToken, async (req, res) => {
    const plans = await db("membership_plans").select("*");
    res.json(plans);
  });

  // Payments
  app.get("/api/payments", authenticateToken, async (req, res) => {
    const payments = await db("payments")
      .join("members", "payments.member_id", "members.id")
      .select("payments.*", "members.name as member_name", "members.member_id as member_code")
      .orderBy("payment_date", "desc");
    res.json(payments);
  });

  app.post("/api/payments", authenticateToken, async (req, res) => {
    const { member_id, amount, payment_method } = req.body;
    try {
      const invoice_number = `INV-${Date.now()}`;
      await db("payments").insert({
        member_id,
        amount,
        payment_method,
        invoice_number,
        payment_date: db.fn.now()
      });
      res.json({ success: true, invoice_number });
    } catch (err) {
      res.status(500).json({ error: "Payment failed" });
    }
  });

  // System Settings
  app.get("/api/settings", authenticateToken, async (req, res) => {
    try {
      const settings = await db("system_settings").select("*");
      const config = settings.reduce((acc: any, curr) => {
        acc[curr.key] = curr.value;
        return acc;
      }, {});
      res.json(config);
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch settings" });
    }
  });

  app.post("/api/settings", authenticateToken, async (req, res) => {
    try {
      const updates = req.body;
      for (const [key, value] of Object.entries(updates)) {
        await db("system_settings")
          .where({ key })
          .update({ value: String(value), updated_at: db.fn.now() });
      }
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: "Failed to update settings" });
    }
  });

  // Trainers
  app.get("/api/trainers", authenticateToken, async (req, res) => {
    try {
      const trainers = await db("trainers").select("*");
      res.json(trainers);
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch trainers" });
    }
  });

  app.post("/api/trainers", authenticateToken, async (req, res) => {
    try {
      const [id] = await db("trainers").insert(req.body);
      const newTrainer = await db("trainers").where({ id }).first();
      res.json(newTrainer);
    } catch (err) {
      res.status(500).json({ error: "Failed to create trainer" });
    }
  });

  app.delete("/api/trainers/:id", authenticateToken, async (req, res) => {
    try {
      await db("trainers").where({ id: req.params.id }).delete();
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: "Failed to delete trainer" });
    }
  });

  // Assignments
  app.post("/api/members/:id/assign-trainer", authenticateToken, async (req, res) => {
    const { trainer_id } = req.body;
    try {
      await db("members").where({ id: req.params.id }).update({ trainer_id });
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: "Assignment failed" });
    }
  });

  // Workout Plans
  app.get("/api/members/:id/workout", authenticateToken, async (req, res) => {
    try {
      const plan = await db("workout_plans").where({ member_id: req.params.id }).first();
      res.json(plan || {});
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch workout plan" });
    }
  });

  app.post("/api/members/:id/workout", authenticateToken, async (req, res) => {
    try {
      const existing = await db("workout_plans").where({ member_id: req.params.id }).first();
      if (existing) {
        await db("workout_plans").where({ id: existing.id }).update(req.body);
      } else {
        await db("workout_plans").insert({ ...req.body, member_id: req.params.id });
      }
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: "Failed to save workout plan" });
    }
  });

  // Diet Plans
  app.get("/api/members/:id/diet", authenticateToken, async (req, res) => {
    try {
      const plan = await db("diet_plans").where({ member_id: req.params.id }).first();
      res.json(plan || {});
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch diet plan" });
    }
  });

  // Expenses
  app.get("/api/expenses", authenticateToken, async (req, res) => {
    try {
      const expenses = await db("expenses").orderBy("date", "desc");
      res.json(expenses);
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch expenses" });
    }
  });

  app.post("/api/expenses", authenticateToken, async (req, res) => {
    try {
      await db("expenses").insert(req.body);
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: "Failed to record expense" });
    }
  });
  // Attendance
  app.get("/api/members/:id/attendance", authenticateToken, async (req, res) => {
    try {
      const attendance = await db("attendance")
        .where({ member_id: req.params.id })
        .orderBy("date", "desc")
        .orderBy("check_in", "desc");
      res.json(attendance);
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch member attendance" });
    }
  });

  app.post("/api/attendance/scan", authenticateToken, async (req, res) => {
    const { member_id_code } = req.body;
    try {
      const member = await db("members").where({ member_id: member_id_code }).first();
      if (!member) return res.status(404).json({ error: "Member not found" });

      const today = new Date().toISOString().split('T')[0];
      const existing = await db("attendance")
        .where({ member_id: member.id, date: today, check_out: null })
        .first();

      if (existing) {
        await db("attendance").where({ id: existing.id }).update({ check_out: db.fn.now() });
        return res.json({ status: "checked_out", member });
      } else {
        await db("attendance").insert({ member_id: member.id, date: today, check_in: db.fn.now() });
        return res.json({ status: "checked_in", member });
      }
    } catch (err) {
      res.status(500).json({ error: "Attendance scan failed" });
    }
  });

  // Dashboard Stats
  app.get("/api/dashboard/stats", authenticateToken, async (req, res) => {
    const totalMembers = await db("members").count("id as count").first();
    const activeMembers = await db("members").where({ is_active: true }).count("id as count").first();
    const totalRevenue = await db("payments").sum("amount as sum").first();
    
    // Last 7 days attendance
    const attendanceStats = await db("attendance")
      .select("date")
      .count("id as count")
      .where("date", ">", db.raw("date('now', '-7 days')"))
      .groupBy("date")
      .orderBy("date", "asc");

    res.json({
      totalMembers: totalMembers?.count || 0,
      activeMembers: activeMembers?.count || 0,
      totalRevenue: totalRevenue?.sum || 0,
      attendanceStats
    });
  });

  // Excel Export
  app.get("/api/reports/export/members", authenticateToken, async (req, res) => {
    const members = await db("members").select("*");
    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet('Members');
    
    sheet.columns = [
      { header: 'ID', key: 'id', width: 10 },
      { header: 'Member Code', key: 'member_id', width: 15 },
      { header: 'Name', key: 'name', width: 30 },
      { header: 'Email', key: 'email', width: 30 },
      { header: 'Phone', key: 'phone', width: 15 },
      { header: 'Expiry', key: 'membership_end', width: 15 },
    ];

    sheet.addRows(members);
    
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename=members.xlsx');
    await workbook.xlsx.write(res);
    res.end();
  });

  // Inventory & POS
  app.get("/api/inventory", authenticateToken, async (req, res) => {
    try {
      const items = await db("inventory").select("*");
      res.json(items);
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch inventory" });
    }
  });

  app.post("/api/inventory", authenticateToken, async (req, res) => {
    try {
      const [id] = await db("inventory").insert(req.body);
      const item = await db("inventory").where({ id }).first();
      res.json(item);
    } catch (err) {
      res.status(500).json({ error: "Failed to add inventory item" });
    }
  });

  app.post("/api/pos/sale", authenticateToken, async (req, res) => {
    const { member_id, items, payment_method, total_amount } = req.body;
    const trx = await db.transaction();
    try {
      const [sale_id] = await trx("sales").insert({
        member_id,
        total_amount,
        payment_method,
        sale_date: trx.fn.now()
      });

      for (const item of items) {
        await trx("sale_items").insert({
          sale_id,
          product_id: item.id,
          quantity: item.quantity,
          unit_price: item.price
        });
        
        // Update stock
        await trx("inventory")
          .where({ id: item.id })
          .decrement("stock", item.quantity);
      }

      await trx.commit();
      res.json({ success: true, sale_id });
    } catch (err) {
      await trx.rollback();
      res.status(500).json({ error: "Sale transaction failed" });
    }
  });

  // Bulk Import Helper (Requested)
  app.post("/api/members/import", authenticateToken, async (req, res) => {
    const { members } = req.body;
    try {
      for (const m of members) {
        const existing = await db("members").where({ email: m.email }).first();
        if (!existing) {
          await db("members").insert({
            ...m,
            is_active: true,
            created_at: db.fn.now()
          });
        }
      }
      res.json({ success: true, count: members.length });
    } catch (err) {
      res.status(500).json({ error: "Bulk import failed" });
    }
  });

  // Backup Manager (Sync all to Excel)
  app.get("/api/admin/backup", authenticateToken, async (req, res) => {
    try {
      const tables = ["members", "attendance", "payments", "trainers", "inventory", "sales", "expenses"];
      const workbook = new ExcelJS.Workbook();
      
      for (const table of tables) {
        const data = await db(table).select("*");
        const sheet = workbook.addWorksheet(table);
        if (data.length > 0) {
          sheet.columns = Object.keys(data[0]).map(key => ({ header: key, key, width: 15 }));
          sheet.addRows(data);
        }
      }

      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', 'attachment; filename=gym_full_backup.xlsx');
      await workbook.xlsx.write(res);
      res.end();
    } catch (err) {
      res.status(500).json({ error: "Backup failed" });
    }
  });

  // --- Vite Middleware ---
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Titan Gym Server running on http://localhost:${PORT}`);
  });
}

startServer();
