/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "./hooks/useAuth.tsx";
import { SettingsProvider } from "./hooks/useSettings.tsx";
import Layout from "./components/layout/Layout.tsx";
import Login from "./pages/Login.tsx";
import Dashboard from "./pages/Dashboard.tsx";
import Attendance from "./pages/Attendance.tsx";
import Members from "./pages/Members.tsx";
import Payments from "./pages/Payments.tsx";
import Trainers from "./pages/Trainers.tsx";
import Expenses from "./pages/Expenses.tsx";
import Inventory from "./pages/Inventory.tsx";
import POS from "./pages/POS.tsx";
import Kiosk from "./pages/Kiosk.tsx";
import Settings from "./pages/Settings.tsx";
import Placeholder from "./components/ui/Placeholder.tsx";

function PrivateRoute({ children }: { children: React.ReactNode }) {
  const { token, isLoading } = useAuth();
  
  if (isLoading) return <div className="h-screen w-screen bg-slate-900 flex items-center justify-center text-white">Loading Titan System...</div>;
  if (!token) return <Navigate to="/login" />;
  
  return <Layout>{children}</Layout>;
}

function KioskRoute({ children }: { children: React.ReactNode }) {
  const { token, isLoading } = useAuth();
  if (isLoading) return <div className="h-screen w-screen bg-slate-950 flex items-center justify-center text-white">Initializing Kiosk...</div>;
  if (!token) return <Navigate to="/login" />;
  return <>{children}</>;
}

export default function App() {
  return (
    <AuthProvider>
      <SettingsProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route 
              path="/" 
              element={
                <PrivateRoute>
                  <Dashboard />
                </PrivateRoute>
              } 
            />
            <Route 
              path="/attendance" 
              element={
                <PrivateRoute>
                  <Attendance />
                </PrivateRoute>
              } 
            />
            <Route 
              path="/members" 
              element={
                <PrivateRoute>
                  <Members />
                </PrivateRoute>
              } 
            />
            <Route 
              path="/inventory" 
              element={
                <PrivateRoute>
                  <Inventory />
                </PrivateRoute>
              } 
            />
            <Route 
              path="/pos" 
              element={
                <PrivateRoute>
                  <POS />
                </PrivateRoute>
              } 
            />
            <Route 
              path="/payments" 
              element={
                <PrivateRoute>
                  <Payments />
                </PrivateRoute>
              } 
            />
            <Route 
              path="/trainers" 
              element={
                <PrivateRoute>
                  <Trainers />
                </PrivateRoute>
              } 
            />
            <Route 
              path="/expenses" 
              element={
                <PrivateRoute>
                  <Expenses />
                </PrivateRoute>
              } 
            />
            <Route 
              path="/kiosk" 
              element={
                <KioskRoute>
                  <Kiosk />
                </KioskRoute>
              } 
            />
            <Route 
              path="/reports" 
              element={
                <PrivateRoute>
                  <Placeholder title="Advanced Reports" />
                </PrivateRoute>
              } 
            />
            <Route 
              path="/settings" 
              element={
                <PrivateRoute>
                  <Settings />
                </PrivateRoute>
              } 
            />
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </BrowserRouter>
      </SettingsProvider>
    </AuthProvider>
  );
}
