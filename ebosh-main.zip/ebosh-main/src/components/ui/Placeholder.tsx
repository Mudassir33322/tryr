export default function Placeholder({ title }: { title: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-20 bg-white rounded-3xl border border-slate-100 italic text-slate-400">
      <p className="text-lg font-medium">{title} Module</p>
      <p className="text-sm">This feature is part of the "Future Expansion" roadmap.</p>
    </div>
  );
}
