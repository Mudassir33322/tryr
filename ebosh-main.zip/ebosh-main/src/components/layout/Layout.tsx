import { ReactNode } from "react";
import { Link, useLocation } from "react-router-dom";
import { useAuth } from "../../hooks/useAuth.tsx";
import { useSettings } from "../../hooks/useSettings.tsx";
import { 
  LayoutDashboard, 
  Users, 
  UserCheck, 
  CreditCard, 
  UserSquare, 
  FileText, 
  Settings, 
  LogOut,
  Dumbbell,
  Receipt,
  Package,
  ShoppingCart,
  Database,
  Cloud,
  CheckCircle2,
  Terminal,
  Search,
  QrCode
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

const NAV_ITEMS = [
  { icon: LayoutDashboard, label: "Dashboard", path: "/" },
  { icon: UserCheck, label: "Attendance", path: "/attendance" },
  { icon: Users, label: "Members", path: "/members" },
  { icon: CreditCard, label: "Payments", path: "/payments" },
  { icon: ShoppingCart, label: "POS Billing", path: "/pos" },
  { icon: Package, label: "Inventory", path: "/inventory" },
  { icon: UserSquare, label: "Trainers", path: "/trainers" },
  { icon: Receipt, label: "Expenses", path: "/expenses" },
  { icon: QrCode, label: "Reception Kiosk", path: "/kiosk" },
  { icon: FileText, label: "Reports", path: "/reports" },
  { icon: Settings, label: "Settings", path: "/settings" },
];

export default function Layout({ children }: { children: ReactNode }) {
  const { user, logout, token } = useAuth();
  const { settings } = useSettings();
  const location = useLocation();

  const handleBackup = async () => {
    try {
      const res = await fetch("/api/admin/backup", {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const blob = await res.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `gym_enterprise_backup_${new Date().toISOString().split('T')[0]}.xlsx`;
        a.click();
      }
    } catch (err) {
      console.error("Backup failed");
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50">
      {/* Sidebar - Desktop Inspired */}
      <aside className="w-64 bg-slate-900 border-r border-slate-800 flex flex-col shadow-2xl relative z-20">
        <div className="p-8 flex items-center gap-4">
          <div className="w-10 h-10 bg-white rounded-2xl flex items-center justify-center shadow-lg shadow-white/10">
            <Dumbbell className="text-slate-900 w-6 h-6" />
          </div>
          <div>
             <span className="font-display font-bold text-lg text-white tracking-tight uppercase block leading-none">{settings.gym_name}</span>
             <span className="text-[9px] text-white/40 font-bold uppercase tracking-[0.2em] mt-1 block">Enterprise ERP</span>
          </div>
        </div>

        <nav className="flex-1 px-4 py-4 space-y-1 overflow-y-auto scrollbar-none">
          {NAV_ITEMS.map((item) => {
            const isActive = location.pathname === item.path;
            const isAttendance = item.path === "/attendance";
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center justify-between px-4 py-3 rounded-2xl transition-all duration-300 group ${
                  isActive 
                    ? "bg-white text-slate-900 shadow-xl shadow-white/5" 
                    : "text-white/50 hover:bg-white/5 hover:text-white"
                }`}
              >
                <div className="flex items-center gap-3">
                  <item.icon className={`w-5 h-5 ${isActive ? "text-slate-900" : "text-white/20 group-hover:text-white"}`} />
                  <span className="font-bold text-sm">{item.label}</span>
                </div>
                {isAttendance && (
                  <div className="flex items-center">
                    <div className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-pulse ring-4 ring-rose-500/20" />
                  </div>
                )}
              </Link>
            );
          })}
        </nav>

        <div className="p-6 mt-auto">
           <button 
             onClick={handleBackup}
             className="w-full flex items-center gap-3 px-4 py-3 bg-white/5 text-white/40 hover:text-white hover:bg-white/10 rounded-2xl transition-all font-bold text-xs"
           >
             <Database className="w-4 h-4" /> Full System Sync
           </button>
        </div>

        <div className="p-6 border-t border-white/5">
          <div className="flex items-center gap-3 px-4 py-3 bg-white/5 rounded-2xl mb-4 group cursor-pointer hover:bg-white/10 transition-all">
            <div className="w-8 h-8 rounded-full bg-indigo-500 flex items-center justify-center font-bold text-white text-xs shadow-lg shadow-indigo-500/20">
              {user?.name.charAt(0)}
            </div>
            <div className="flex-1 overflow-hidden">
              <p className="text-sm font-bold text-white truncate">{user?.name}</p>
              <p className="text-[9px] text-white/30 uppercase tracking-widest font-black leading-none mt-1">{user?.role}</p>
            </div>
          </div>
          <button 
            onClick={logout}
            className="flex items-center gap-3 w-full px-4 py-3 text-rose-500 hover:bg-rose-500/10 rounded-2xl transition-all font-bold text-sm"
          >
            <LogOut className="w-4 h-4" />
            <span>Terminate Session</span>
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col h-full relative">
        <header className="h-16 bg-white border-b border-slate-200 px-10 flex items-center justify-between sticky top-0 z-10">
          <div className="flex items-center gap-6">
            <h2 className="font-display font-bold text-xl text-slate-900 tracking-tight">
              {NAV_ITEMS.find(i => i.path === location.pathname)?.label || "Titan Gym"}
            </h2>
            <div className="h-4 w-[1px] bg-slate-200" />
            <div className="flex items-center gap-2 text-slate-400">
               <Terminal className="w-4 h-4" />
               <span className="text-[10px] font-bold uppercase tracking-widest">Workspace / Root</span>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
             <div className="relative group">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 group-focus-within:text-indigo-600 transition-colors" />
                <input 
                  type="text" 
                  placeholder="Ctrl + K to Search..." 
                  className="bg-slate-50 border-0 rounded-xl pl-10 pr-4 py-2 text-xs font-bold w-64 focus:ring-2 focus:ring-indigo-500 transition-all"
                />
             </div>
             <div className="h-8 w-8 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-center text-slate-400 hover:text-slate-900 cursor-pointer transition-all">
                <Cloud className="w-4 h-4" />
             </div>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto bg-slate-50/50 relative">
          <div className="p-10 max-w-7xl mx-auto">
            <AnimatePresence mode="wait">
              <motion.div
                key={location.pathname}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3, ease: "easeOut" }}
              >
                {children}
              </motion.div>
            </AnimatePresence>
          </div>
        </main>

        {/* Professional Status Bar */}
        <footer className="h-8 bg-white border-t border-slate-200 px-6 flex items-center justify-between text-[10px] font-bold text-slate-400 uppercase tracking-widest">
           <div className="flex items-center gap-6">
              <div className="flex items-center gap-2 text-emerald-500">
                 <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                 <span>System Online</span>
              </div>
              <div className="flex items-center gap-2">
                 <Database className="w-3 h-3" />
                 <span>SQLite (Enterprise)</span>
              </div>
              <div className="flex items-center gap-2">
                 <CheckCircle2 className="w-3 h-3 text-indigo-500" />
                 <span>Excel Engine: Active</span>
              </div>
           </div>
           <div className="flex items-center gap-6">
              <span>{settings.gym_name} v4.0.0-PRO</span>
              <div className="flex items-center gap-2">
                 <div className="w-4 h-4 rounded bg-slate-100 flex items-center justify-center">?</div>
                 <span>Support Ready</span>
              </div>
           </div>
        </footer>
      </div>
    </div>
  );
}
