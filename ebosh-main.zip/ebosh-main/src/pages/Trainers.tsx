import React, { useState, useEffect } from "react";
import { useAuth } from "../hooks/useAuth.tsx";
import { 
  Users, 
  Search, 
  Plus, 
  Phone, 
  Mail, 
  Award, 
  DollarSign,
  TrendingUp,
  MoreVertical,
  ChevronRight,
  Filter,
  CheckCircle2
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner";

interface Trainer {
  id: number;
  name: string;
  email: string;
  phone: string;
  specialization: string;
  salary: number;
  bio: string;
  is_active: boolean;
}

export default function Trainers() {
  const { token } = useAuth();
  const [trainers, setTrainers] = useState<Trainer[]>([]);
  const [search, setSearch] = useState("");
  const [showAddModal, setShowAddModal] = useState(false);
  const [loading, setLoading] = useState(true);

  const [newTrainer, setNewTrainer] = useState({
    name: "",
    email: "",
    phone: "",
    specialization: "General Fitness",
    salary: 0,
    bio: ""
  });

  const fetchData = async () => {
    try {
      const res = await fetch("/api/trainers", {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      setTrainers(data);
    } catch (err) {
      toast.error("Failed to load trainers");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [token]);

  const handleAddTrainer = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch("/api/trainers", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(newTrainer)
      });
      if (res.ok) {
        toast.success("Trainer added successfully");
        setShowAddModal(false);
        fetchData();
        setNewTrainer({ name: "", email: "", phone: "", specialization: "General Fitness", salary: 0, bio: "" });
      }
    } catch (err) {
      toast.error("Failed to add trainer");
    }
  };

  const filteredTrainers = trainers.filter(t => 
    t.name.toLowerCase().includes(search.toLowerCase()) ||
    t.specialization.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-display font-bold text-slate-900">Expert Trainers</h1>
          <p className="text-slate-500 font-medium">Manage your elite coaching staff and their performance</p>
        </div>
        
        <button 
          onClick={() => setShowAddModal(true)}
          className="px-6 py-3 bg-slate-900 text-white rounded-2xl font-bold flex items-center gap-2 hover:bg-slate-800 transition-all shadow-xl shadow-slate-900/10"
        >
          <Plus className="w-5 h-5" /> Hire Trainer
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
        <div className="glass-card p-6 bg-white border-0 shadow-sm flex items-center gap-4">
           <div className="w-14 h-14 bg-indigo-50 rounded-2xl flex items-center justify-center text-indigo-600">
             <Users className="w-7 h-7" />
           </div>
           <div>
             <p className="text-xs font-bold text-slate-400 font-display uppercase tracking-[0.1em]">Total Staff</p>
             <p className="text-2xl font-bold text-slate-900">{trainers.length}</p>
           </div>
        </div>
        <div className="glass-card p-6 bg-white border-0 shadow-sm flex items-center gap-4">
           <div className="w-14 h-14 bg-emerald-50 rounded-2xl flex items-center justify-center text-emerald-600">
             <DollarSign className="w-7 h-7" />
           </div>
           <div>
             <p className="text-xs font-bold text-slate-400 font-display uppercase tracking-[0.1em]">Monthly Payroll</p>
             <p className="text-2xl font-bold text-slate-900">${trainers.reduce((acc, curr) => acc + (curr.salary || 0), 0).toLocaleString()}</p>
           </div>
        </div>
        <div className="glass-card p-6 bg-slate-900 border-0 shadow-xl shadow-slate-900/10 flex items-center gap-4 text-white">
           <div className="w-14 h-14 bg-white/10 rounded-2xl flex items-center justify-center">
             <Award className="w-7 h-7" />
           </div>
           <div>
             <p className="text-xs font-bold text-white/50 font-display uppercase tracking-[0.1em]">Top Performer</p>
             <p className="text-2xl font-bold">Coach S. Parker</p>
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredTrainers.map((trainer) => (
          <motion.div 
            layout
            key={trainer.id}
            className="glass-card bg-white border-0 shadow-lg shadow-slate-200/50 overflow-hidden rounded-[2.5rem] group hover:scale-[1.02] transition-all"
          >
            <div className="h-24 bg-gradient-to-br from-indigo-500 to-purple-600 p-6 flex justify-end">
               <span className="p-2 bg-white/20 backdrop-blur rounded-xl h-fit">
                  <CheckCircle2 className="w-4 h-4 text-white" />
               </span>
            </div>
            
            <div className="px-8 pb-8 -mt-12">
               <div className="relative">
                 <div className="w-24 h-24 rounded-[2rem] bg-white p-1 shadow-xl shadow-indigo-500/10">
                   <div className="w-full h-full rounded-[1.8rem] bg-slate-100 flex items-center justify-center text-3xl font-display font-bold text-indigo-600 overflow-hidden">
                     {trainer.name.charAt(0)}
                   </div>
                 </div>
                 <div className="absolute bottom-0 right-2 w-6 h-6 bg-emerald-500 border-4 border-white rounded-full"></div>
               </div>

               <div className="mt-6">
                 <h3 className="text-2xl font-display font-bold text-slate-900">{trainer.name}</h3>
                 <p className="text-sm font-bold text-indigo-600 bg-indigo-50 w-fit px-3 py-1 rounded-full mt-2">
                   {trainer.specialization}
                 </p>
               </div>

               <div className="mt-8 space-y-4">
                  <div className="flex items-center gap-3 text-slate-400 group-hover:text-slate-600 transition-colors">
                    <Phone className="w-4 h-4" />
                    <span className="text-sm font-medium">{trainer.phone || 'No phone'}</span>
                  </div>
                  <div className="flex items-center gap-3 text-slate-400 group-hover:text-slate-600 transition-colors">
                    <Mail className="w-4 h-4" />
                    <span className="text-sm font-medium">{trainer.email || 'No email'}</span>
                  </div>
               </div>

               <div className="mt-8 pt-8 border-t border-slate-50 flex items-center justify-between">
                  <div>
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none mb-1">Salary</p>
                    <p className="text-xl font-bold text-slate-900">${trainer.salary?.toLocaleString()}</p>
                  </div>
                  <button className="p-4 bg-slate-50 text-slate-400 rounded-2xl hover:bg-slate-900 hover:text-white transition-all">
                    <ChevronRight className="w-5 h-5" />
                  </button>
               </div>
            </div>
          </motion.div>
        ))}
      </div>

      <AnimatePresence>
        {showAddModal && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="bg-white rounded-[3rem] w-full max-w-xl overflow-hidden shadow-2xl"
            >
              <div className="p-10 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
                <div>
                  <h2 className="text-3xl font-display font-bold text-slate-900">New Trainer</h2>
                  <p className="text-sm text-slate-500 font-medium">Add a professional coach to your gym</p>
                </div>
                <button 
                  onClick={() => setShowAddModal(false)}
                  className="p-4 hover:bg-white rounded-2xl transition-all text-slate-300 hover:text-slate-900"
                >
                  <Plus className="w-8 h-8 rotate-45" />
                </button>
              </div>

              <form onSubmit={handleAddTrainer} className="p-10 space-y-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Full Name</label>
                  <input 
                    required
                    type="text"
                    className="w-full px-6 py-5 bg-slate-50 border-0 rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-medium text-lg"
                    placeholder="Coach name"
                    value={newTrainer.name}
                    onChange={e => setNewTrainer({...newTrainer, name: e.target.value})}
                  />
                </div>

                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Email</label>
                    <input 
                      type="email"
                      className="w-full px-6 py-5 bg-slate-50 border-0 rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-medium"
                      placeholder="email@example.com"
                      value={newTrainer.email}
                      onChange={e => setNewTrainer({...newTrainer, email: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Phone Number</label>
                    <input 
                      type="text"
                      className="w-full px-6 py-5 bg-slate-50 border-0 rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-medium"
                      placeholder="+1 (555) 000-0000"
                      value={newTrainer.phone}
                      onChange={e => setNewTrainer({...newTrainer, phone: e.target.value})}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Specialization</label>
                    <select 
                      className="w-full px-6 py-5 bg-slate-50 border-0 rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-bold"
                      value={newTrainer.specialization}
                      onChange={e => setNewTrainer({...newTrainer, specialization: e.target.value})}
                    >
                      <option>General Fitness</option>
                      <option>Bodybuilding</option>
                      <option>Yoga & Mobility</option>
                      <option>Powerlifting</option>
                      <option>Cardio Expert</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Monthly Salary ($)</label>
                    <input 
                      type="number"
                      className="w-full px-6 py-5 bg-slate-50 border-0 rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-bold"
                      value={newTrainer.salary}
                      onChange={e => setNewTrainer({...newTrainer, salary: parseFloat(e.target.value)})}
                    />
                  </div>
                </div>

                <div className="pt-6 flex gap-4">
                  <button 
                    type="submit"
                    className="flex-1 py-5 bg-slate-900 text-white rounded-[1.8rem] font-bold text-lg hover:bg-slate-800 transition-all shadow-xl shadow-slate-900/10"
                  >
                    Hire Coach
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
