import { useEffect, useRef, useState } from "react";
import { Html5QrcodeScanner } from "html5-qrcode";
import { useAuth } from "../hooks/useAuth.tsx";
import { QrCode, User, CheckCircle2, XCircle, Clock, TrendingUp } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function Attendance() {
  const [scanResult, setScanResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const { token } = useAuth();
  const scannerRef = useRef<Html5QrcodeScanner | null>(null);

  useEffect(() => {
    if (isScanning && !scannerRef.current) {
      scannerRef.current = new Html5QrcodeScanner(
        "reader",
        { fps: 10, qrbox: { width: 250, height: 250 } },
        false
      );

      scannerRef.current.render(async (decodedText) => {
        setIsScanning(false);
        scannerRef.current?.clear();
        scannerRef.current = null;
        await handleScan(decodedText);
      }, (err) => {
        // console.warn(err);
      });
    }

    return () => {
      if (scannerRef.current) {
        scannerRef.current.clear();
        scannerRef.current = null;
      }
    };
  }, [isScanning]);

  const handleScan = async (code: string) => {
    try {
      const response = await fetch("/api/attendance/scan", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ member_id_code: code })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error);
      setScanResult(data);
      setTimeout(() => {
        setScanResult(null);
        setIsScanning(true);
      }, 5000);
    } catch (err: any) {
      setError(err.message);
      setTimeout(() => setError(null), 3000);
      setIsScanning(true);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-display font-bold">QR Attendance</h2>
          <p className="text-slate-500">Scan member QR code for check-in/out</p>
        </div>
        {!isScanning && !scanResult && (
           <button 
            onClick={() => setIsScanning(true)}
            className="flex items-center gap-2 bg-slate-900 text-white px-6 py-3 rounded-xl font-bold shadow-lg"
           >
             <QrCode className="w-5 h-5" /> Start Scanner
           </button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
        {/* Scanner Window */}
        <div className="glass-card overflow-hidden">
          <div className="bg-slate-900 p-4 flex items-center justify-between">
             <span className="text-white font-bold text-xs uppercase tracking-widest flex items-center gap-2">
               <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
               Live Camera Feed
             </span>
          </div>
          <div id="reader" className="w-full aspect-square bg-slate-100 flex items-center justify-center">
            {!isScanning && !scanResult && (
               <div className="text-center p-12">
                 <QrCode className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                 <p className="text-slate-400 font-medium">Camera is offline</p>
               </div>
            )}
          </div>
        </div>

        {/* Result Area */}
        <div className="space-y-6">
          <AnimatePresence mode="wait">
            {scanResult ? (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className={`glass-card p-8 border-t-8 ${scanResult.status === 'checked_in' ? 'border-t-emerald-500' : 'border-t-amber-500'}`}
              >
                <div className="flex items-center gap-4 mb-6">
                  {scanResult.status === 'checked_in' ? (
                    <div className="w-16 h-16 bg-emerald-50 text-emerald-500 rounded-full flex items-center justify-center">
                      <CheckCircle2 className="w-10 h-10" />
                    </div>
                  ) : (
                    <div className="w-16 h-16 bg-amber-50 text-amber-500 rounded-full flex items-center justify-center">
                      <Clock className="w-10 h-10" />
                    </div>
                  )}
                  <div>
                    <h3 className="text-xl font-bold">{scanResult.status === 'checked_in' ? 'Checked In' : 'Checked Out'}</h3>
                    <p className="text-slate-500 font-medium">Successfully recorded</p>
                  </div>
                </div>

                <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100 mb-6">
                   <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-slate-200 rounded-xl flex items-center justify-center">
                        <User className="text-slate-400" />
                      </div>
                      <div>
                        <p className="font-bold text-slate-900">{scanResult.member.name}</p>
                        <p className="text-xs text-slate-400 font-bold tracking-widest uppercase">{scanResult.member.member_id}</p>
                      </div>
                   </div>
                </div>

                <div className="text-sm text-slate-400 text-center font-medium italic">
                  Resetting in 5 seconds...
                </div>
              </motion.div>
            ) : error ? (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="glass-card p-8 border-t-8 border-t-red-500 bg-red-50/30"
              >
                <div className="flex justify-center mb-4">
                   <div className="w-16 h-16 bg-red-50 text-red-500 rounded-full flex items-center justify-center">
                    <XCircle className="w-10 h-10" />
                  </div>
                </div>
                <h3 className="text-xl font-bold text-center text-red-600 mb-2">Scan Failed</h3>
                <p className="text-red-500 text-center font-medium">{error}</p>
                <p className="text-xs text-slate-400 mt-6 text-center">Retrying automatically...</p>
              </motion.div>
            ) : (
              <div className="glass-card p-12 text-center opacity-50 border-dashed">
                <QrCode className="w-20 h-20 text-slate-200 mx-auto mb-6" />
                <h3 className="text-slate-400 font-bold text-lg mb-2">Scanner Ready</h3>
                <p className="text-slate-300 text-sm max-w-xs mx-auto">Positions the member QR code within the highlighted camera frame to record attendance.</p>
              </div>
            )}
          </AnimatePresence>

          <div className="glass-card p-6">
            <h4 className="font-bold text-slate-900 mb-4 flex items-center gap-2">
              <Activity className="w-4 h-4 text-slate-400" /> Recent Scans
            </h4>
            <div className="space-y-3">
              {[1, 2].map(i => (
                <div key={i} className="flex items-center justify-between text-sm py-2 border-b border-slate-50 last:border-0">
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 rounded-full bg-emerald-500" />
                    <span className="font-semibold">09:45 AM</span>
                  </div>
                  <span className="text-slate-500">Alex Johnson</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Activity({ className }: { className: string }) {
  return <TrendingUp className={className} />;
}
