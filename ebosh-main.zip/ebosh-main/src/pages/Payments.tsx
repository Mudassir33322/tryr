import React, { useState, useEffect } from "react";
import { useAuth } from "../hooks/useAuth.tsx";
import { 
  CreditCard, 
  Plus, 
  Search, 
  TrendingUp, 
  ArrowDownLeft,
  Calendar,
  User,
  DollarSign,
  Download
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner";

interface Payment {
  id: number;
  member_name: string;
  member_code: string;
  amount: number;
  payment_method: string;
  invoice_number: string;
  payment_date: string;
}

interface Member {
  id: number;
  name: string;
  member_id: string;
}

export default function Payments() {
  const [payments, setPayments] = useState<Payment[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const { token } = useAuth();

  // Form State
  const [selectedMember, setSelectedMember] = useState("");
  const [amount, setAmount] = useState("");
  const [method, setMethod] = useState("Cash");

  const fetchData = async () => {
    try {
      const [payRes, memRes] = await Promise.all([
        fetch("/api/payments", { headers: { Authorization: `Bearer ${token}` } }),
        fetch("/api/members", { headers: { Authorization: `Bearer ${token}` } })
      ]);
      const payData = await payRes.json();
      const memData = await memRes.json();
      
      if (Array.isArray(payData)) setPayments(payData);
      if (Array.isArray(memData)) setMembers(memData);
    } catch (err) {
      toast.error("Failed to load records");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (token) fetchData();
  }, [token]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMember || !amount) return toast.error("Please fill all fields");

    try {
      const res = await fetch("/api/payments", {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ 
          member_id: selectedMember, 
          amount: parseFloat(amount), 
          payment_method: method 
        })
      });
      if (!res.ok) throw new Error();
      toast.success("Payment recorded successfully!");
      setShowForm(false);
      setSelectedMember("");
      setAmount("");
      fetchData();
    } catch (err) {
      toast.error("Process failed");
    }
  };

  const totalRevenue = payments.reduce((acc, curr) => acc + curr.amount, 0);

  return (
    <div className="space-y-8">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-display font-bold tracking-tight">Financial Hub</h2>
          <p className="text-slate-500 font-medium tracking-tight">Revenue tracking and invoice management</p>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setShowForm(!showForm)}
            className="flex items-center gap-2 bg-slate-900 text-white px-6 py-3 rounded-2xl font-bold shadow-xl shadow-slate-900/10 hover:-translate-y-0.5 transition-all"
          >
            <Plus className="w-5 h-5" /> {showForm ? "Close Form" : "New Payment"}
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="glass-card p-6 bg-slate-900 text-white border-0">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-white/10 rounded-lg"><DollarSign className="w-5 h-5" /></div>
            <ArrowDownLeft className="w-5 h-5 text-emerald-400" />
          </div>
          <p className="text-slate-400 text-sm font-medium">Total Volume</p>
          <h3 className="text-3xl font-display font-bold mt-1">${totalRevenue.toLocaleString()}</h3>
        </div>
        <div className="glass-card p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-slate-100 rounded-lg text-slate-600"><CreditCard className="w-5 h-5" /></div>
            <TrendingUp className="w-5 h-5 text-emerald-500" />
          </div>
          <p className="text-slate-400 text-sm font-medium">Transactions</p>
          <h3 className="text-3xl font-display font-bold mt-1 text-slate-900">{payments.length}</h3>
        </div>
        <div className="glass-card p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-slate-100 rounded-lg text-slate-600"><Calendar className="w-5 h-5" /></div>
          </div>
          <p className="text-slate-400 text-sm font-medium">Average Ticket</p>
          <h3 className="text-3xl font-display font-bold mt-1 text-slate-900">
            ${payments.length > 0 ? (totalRevenue / payments.length).toFixed(2) : "0"}
          </h3>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Payment Form */}
        <AnimatePresence>
          {showForm && (
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="lg:col-span-1"
            >
              <div className="glass-card p-8 sticky top-24">
                <h3 className="text-xl font-display font-bold mb-6">Process Transaction</h3>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700">Select Member</label>
                    <select 
                      value={selectedMember}
                      onChange={(e) => setSelectedMember(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 outline-none focus:ring-2 focus:ring-slate-900/5 focus:border-slate-900 transition-all"
                    >
                      <option value="">-- Choose Member --</option>
                      {members.map(m => (
                        <option key={m.id} value={m.id}>{m.name} ({m.member_id})</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700">Amount ($)</label>
                    <input 
                      type="number"
                      placeholder="0.00"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 outline-none focus:ring-2 focus:ring-slate-900/5 focus:border-slate-900 transition-all font-mono"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700">Payment Mode</label>
                    <select 
                      value={method}
                      onChange={(e) => setMethod(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3"
                    >
                      <option value="Cash">Cash</option>
                      <option value="Card">Card</option>
                      <option value="Online">Online Transfer</option>
                      <option value="Crypto">Cryptocurrency</option>
                    </select>
                  </div>

                  <button className="w-full bg-emerald-600 text-white font-bold py-4 rounded-xl hover:bg-emerald-700 transition-all mt-4 shadow-lg shadow-emerald-600/10">
                    Validate & Confirm
                  </button>
                </form>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Payments List */}
        <div className={showForm ? "lg:col-span-2" : "lg:col-span-3"}>
          <div className="glass-card overflow-hidden">
             <div className="p-6 border-b border-slate-100 flex items-center justify-between">
                <h3 className="font-display font-bold">Transaction Ledger</h3>
                <div className="relative">
                   <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                   <input 
                    placeholder="Search invoices..." 
                    className="bg-slate-50 border-0 rounded-lg py-2 pl-9 pr-4 text-xs font-medium focus:ring-1 focus:ring-slate-200 outline-none"
                   />
                </div>
             </div>
             <div className="overflow-x-auto">
               <table className="w-full text-left">
                 <thead className="bg-slate-50 text-[10px] uppercase font-bold text-slate-400 tracking-widest">
                   <tr>
                     <th className="px-6 py-4">Transaction Details</th>
                     <th className="px-6 py-4">Status</th>
                     <th className="px-6 py-4">Amount</th>
                     <th className="px-6 py-4">Method</th>
                     <th className="px-6 py-4">Date</th>
                     <th className="px-6 py-4 text-right">Invoice</th>
                   </tr>
                 </thead>
                 <tbody className="divide-y divide-slate-50">
                    {payments.map(p => (
                      <tr key={p.id} className="hover:bg-slate-50/50 transition-colors">
                        <td className="px-6 py-4">
                           <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center text-slate-400 italic font-bold text-[10px]">
                                {p.member_name.charAt(0)}
                              </div>
                              <div>
                                <p className="text-sm font-bold text-slate-900">{p.member_name}</p>
                                <p className="text-[10px] text-slate-400 font-bold uppercase">{p.invoice_number}</p>
                              </div>
                           </div>
                        </td>
                        <td className="px-6 py-4">
                           <span className="bg-emerald-50 text-emerald-600 text-[10px] font-bold px-2 py-0.5 rounded-full">Cleared</span>
                        </td>
                        <td className="px-6 py-4 font-mono font-bold text-slate-900 text-sm">
                           ${p.amount.toFixed(2)}
                        </td>
                        <td className="px-6 py-4 text-xs font-medium text-slate-500">
                           {p.payment_method}
                        </td>
                        <td className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase">
                           {new Date(p.payment_date).toLocaleDateString()}
                        </td>
                        <td className="px-6 py-4 text-right">
                           <button className="p-2 hover:bg-slate-100 rounded-lg text-slate-400 transition-colors">
                             <Download className="w-4 h-4" />
                           </button>
                        </td>
                      </tr>
                    ))}
                 </tbody>
               </table>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
}
