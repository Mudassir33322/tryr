import { useState, useEffect } from "react";
import { useAuth } from "../hooks/useAuth.tsx";
import { useSettings } from "../hooks/useSettings.tsx";
import { 
  Shield, 
  Database, 
  Palette, 
  Monitor, 
  Save,
  Trash2,
  AlertTriangle,
  Lock,
  Smartphone,
  Moon,
  Sun,
  Layout,
  RefreshCw,
  Cloud,
  Download,
  Info,
  Plus
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner";

type TabType = "general" | "security" | "appearance" | "backup";

export default function Settings() {
  const [activeTab, setActiveTab] = useState<TabType>("general");
  const { token } = useAuth();
  const { settings, updateSettings } = useSettings();
  const [localSettings, setLocalSettings] = useState(settings);

  useEffect(() => {
    setLocalSettings(settings);
  }, [settings]);

  const handleSave = async () => {
    try {
      await updateSettings(localSettings);
      toast.success("System configurations updated permanently!");
    } catch (err) {
      toast.error("Failed to save settings");
    }
  };

  const handleManualExport = async (format: "json" | "csv") => {
    try {
      const res = await fetch(`/api/members?export=${format}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const blob = await res.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `members_backup.${format}`;
        a.click();
        toast.success(`Backup exported as ${format.toUpperCase()}`);
      }
    } catch (err) {
      toast.error("Export failed");
    }
  };

  const tabs = [
    { id: "general" as TabType, label: "General", icon: Monitor },
    { id: "security" as TabType, label: "Security & Auth", icon: Shield },
    { id: "appearance" as TabType, label: "Appearance", icon: Palette },
    { id: "backup" as TabType, label: "Backup & Recovery", icon: Database },
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-display font-bold tracking-tight text-slate-900">System Control</h2>
          <p className="text-slate-500 font-medium tracking-tight">Global environment and security policies</p>
        </div>
        <div className="flex gap-3">
          <button 
            className="flex items-center gap-2 bg-slate-100 text-slate-600 px-6 py-3 rounded-2xl font-bold hover:bg-slate-200 transition-all"
          >
            <RefreshCw className="w-4 h-4" /> Reset
          </button>
          <button 
            onClick={handleSave}
            className="flex items-center gap-2 bg-slate-900 text-white px-6 py-3 rounded-2xl font-bold hover:scale-[1.02] transition-all shadow-xl shadow-slate-900/10"
          >
            <Save className="w-5 h-5" /> Save Changes
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
        <div className="md:col-span-1 space-y-1">
           {tabs.map((tab) => (
             <button 
               key={tab.id}
               onClick={() => setActiveTab(tab.id)}
               className={`w-full text-left px-5 py-4 rounded-2xl font-bold flex items-center gap-4 transition-all ${
                 activeTab === tab.id 
                 ? "bg-slate-900 text-white shadow-xl shadow-slate-900/10 scale-[1.02]" 
                 : "text-slate-500 hover:bg-white hover:text-slate-900"
               }`}
             >
               <tab.icon className="w-5 h-5" />
               <span className="text-sm">{tab.label}</span>
             </button>
           ))}
           
           <div className="pt-8 px-5">
              <div className="p-4 bg-slate-100 rounded-2xl">
                 <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2 mb-2">
                    <Info className="w-3 h-3" /> System Info
                 </p>
                 <div className="space-y-1">
                    <p className="text-xs font-bold text-slate-700">v2.4.0-pro</p>
                    <p className="text-[10px] text-slate-400">Node v20.x • SQLite</p>
                 </div>
              </div>
           </div>
        </div>

        <div className="md:col-span-3 space-y-6">
           <AnimatePresence mode="wait">
             <motion.div 
               key={activeTab}
               initial={{ opacity: 0, x: 10 }}
               animate={{ opacity: 1, x: 0 }}
               exit={{ opacity: 0, x: -10 }}
               transition={{ duration: 0.2 }}
               className="space-y-6"
             >
                {activeTab === "general" && (
                   <div className="space-y-6">
                      <div className="glass-card p-8">
                        <h3 className="text-lg font-display font-bold mb-6 flex items-center gap-2">
                          <Monitor className="w-5 h-5 text-slate-400" /> General Settings
                        </h3>
                        
                        <div className="space-y-6">
                          <div className="space-y-2">
                            <label className="text-sm font-bold text-slate-700">Gym Identity</label>
                            <input 
                              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 outline-none focus:ring-4 focus:ring-slate-900/5 transition-all"
                              value={localSettings.gym_name}
                              onChange={(e) => setLocalSettings({...localSettings, gym_name: e.target.value})}
                            />
                            <p className="text-[10px] text-slate-400 font-medium">This name will appear on receipts and member badges.</p>
                          </div>

                          <div className="grid grid-cols-2 gap-6">
                            <div className="space-y-2">
                              <label className="text-sm font-bold text-slate-700">Display Currency</label>
                              <select 
                                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3"
                                value={localSettings.currency}
                                onChange={(e) => setLocalSettings({...localSettings, currency: e.target.value})}
                              >
                                <option value="USD">USD ($)</option>
                                <option value="EUR">EUR (€)</option>
                                <option value="GBP">GBP (£)</option>
                                <option value="PKR">PKR (Rs)</option>
                              </select>
                            </div>
                            <div className="space-y-2">
                              <label className="text-sm font-bold text-slate-700">Gym Address</label>
                              <input 
                                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3"
                                value={localSettings.address}
                                onChange={(e) => setLocalSettings({...localSettings, address: e.target.value})}
                              />
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="glass-card p-8 bg-amber-50/30 border-amber-100">
                        <div className="flex items-start gap-4">
                           <div className="p-3 bg-white rounded-2xl shadow-sm text-amber-600">
                              <AlertTriangle className="w-6 h-6" />
                           </div>
                           <div className="flex-1">
                              <h4 className="text-lg font-display font-bold text-slate-900">Danger Zone</h4>
                              <p className="text-sm text-slate-500 mt-1 leading-relaxed">Destructive operations that cannot be reversed. Please proceed with caution.</p>
                              <div className="mt-6 flex flex-wrap gap-4">
                                 <button className="px-5 py-3 bg-white border border-red-200 text-red-600 rounded-xl text-xs font-bold hover:bg-red-50 transition-all flex items-center gap-2 shadow-sm">
                                    <Trash2 className="w-4 h-4" /> Reset All Database Tables
                                 </button>
                                 <button className="px-5 py-3 bg-red-600 text-white rounded-xl text-xs font-bold hover:bg-red-700 transition-all flex items-center gap-2 shadow-sm">
                                    Purge Inactive Members
                                 </button>
                              </div>
                           </div>
                        </div>
                      </div>
                   </div>
                )}

                {activeTab === "security" && (
                  <div className="space-y-6">
                    <div className="glass-card p-8">
                       <h3 className="text-lg font-display font-bold mb-6 flex items-center gap-2">
                        <Lock className="w-5 h-5 text-slate-400" /> Authentication Policies
                       </h3>
                       
                       <div className="space-y-6">
                          <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl">
                             <div>
                                <p className="text-sm font-bold text-slate-900">Two-Factor Authentication (2FA)</p>
                                <p className="text-xs text-slate-500 mt-0.5">Require mobile app code for staff login</p>
                             </div>
                             <div className="w-12 h-6 bg-slate-200 rounded-full relative cursor-pointer group">
                                <div className="absolute left-1 top-1 w-4 h-4 bg-white rounded-full transition-all group-hover:scale-110"></div>
                             </div>
                          </div>

                          <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl">
                             <div>
                                <p className="text-sm font-bold text-slate-900">Session Expiration</p>
                                <p className="text-xs text-slate-500 mt-0.5">Auto logged out after 30 mins of inactivity</p>
                             </div>
                             <select className="bg-transparent text-xs font-bold text-slate-700 outline-none">
                                <option>15 mins</option>
                                <option>30 mins</option>
                                <option>1 hour</option>
                                <option>Never</option>
                             </select>
                          </div>

                          <div className="p-4 bg-blue-50 border border-blue-100 rounded-2xl flex items-start gap-3">
                             <Lock className="w-4 h-4 text-blue-500 mt-1" />
                             <div>
                                <p className="text-xs font-bold text-blue-900">Password Complexity Active</p>
                                <p className="text-[10px] text-blue-700 mt-1">Passwords must contain 8+ characters, symbol, and number.</p>
                             </div>
                          </div>
                       </div>
                    </div>

                    <div className="glass-card p-8">
                       <h3 className="text-lg font-display font-bold mb-6 flex items-center gap-2">
                        <Smartphone className="w-5 h-5 text-slate-400" /> API Access
                       </h3>
                       <div className="space-y-2">
                          <label className="text-xs font-bold text-slate-500 uppercase tracking-widest pl-1">Secret Key Token</label>
                          <div className="flex gap-2">
                             <input 
                               readOnly
                               type="password"
                               value="sk_live_23948203948203948"
                               className="flex-1 bg-slate-50 border border-slate-200 rounded-xl p-3 font-mono text-xs"
                             />
                             <button className="px-4 py-2 bg-slate-100 text-slate-600 rounded-xl text-xs font-bold">Copy</button>
                          </div>
                       </div>
                    </div>
                  </div>
                )}

                {activeTab === "appearance" && (
                  <div className="space-y-6">
                    <div className="glass-card p-8">
                       <h3 className="text-lg font-display font-bold mb-6 flex items-center gap-2">
                        <Palette className="w-5 h-5 text-slate-400" /> Interface Customization
                       </h3>

                       <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                          <div className="space-y-4">
                             <label className="text-sm font-bold text-slate-700">Display Theme</label>
                             <div className="grid grid-cols-2 gap-3">
                                <button 
                                  onClick={() => setLocalSettings({...localSettings, theme: "light"})}
                                  className={`p-4 border-2 rounded-2xl flex flex-col items-center gap-2 transition-all ${
                                    localSettings.theme === "light" 
                                    ? "border-slate-900 bg-white" 
                                    : "border-transparent bg-slate-50 text-slate-400"
                                  }`}
                                >
                                   <Sun className="w-6 h-6" />
                                   <span className="text-xs font-bold">Light</span>
                                </button>
                                <button 
                                  onClick={() => setLocalSettings({...localSettings, theme: "dark"})}
                                  className={`p-4 border-2 rounded-2xl flex flex-col items-center gap-2 transition-all ${
                                    localSettings.theme === "dark" 
                                    ? "border-indigo-500 bg-slate-900 text-white" 
                                    : "border-transparent bg-slate-50 text-slate-400"
                                  }`}
                                >
                                   <Moon className="w-6 h-6" />
                                   <span className="text-xs font-bold">Dark</span>
                                </button>
                             </div>
                          </div>

                          <div className="space-y-4">
                             <label className="text-sm font-bold text-slate-700">Density Layout</label>
                             <div className="grid grid-cols-2 gap-3">
                                <button className="p-4 border-2 border-slate-900 rounded-2xl flex flex-col items-center gap-2">
                                   <Layout className="w-6 h-6" />
                                   <span className="text-xs font-bold">Comfortable</span>
                                </button>
                                <button className="p-4 border-2 border-transparent bg-slate-50 rounded-2xl flex flex-col items-center gap-2 text-slate-400 hover:bg-slate-100 transition-all">
                                   <div className="w-6 h-6 flex flex-col gap-0.5">
                                      <div className="w-full h-1 bg-slate-300 rounded-full"></div>
                                      <div className="w-full h-1 bg-slate-300 rounded-full"></div>
                                      <div className="w-full h-1 bg-slate-300 rounded-full"></div>
                                   </div>
                                   <span className="text-xs font-bold">Compact</span>
                                </button>
                             </div>
                          </div>
                       </div>
                    </div>

                    <div className="glass-card p-8">
                       <h3 className="text-sm font-bold mb-4">Sidebar Branding Color</h3>
                       <div className="flex gap-4">
                          {['#0f172a', '#4f46e5', '#db2777', '#059669', '#d97706'].map(color => (
                             <button 
                                key={color}
                                className="w-10 h-10 rounded-full border-4 border-white shadow-sm"
                                style={{ backgroundColor: color }}
                             ></button>
                          ))}
                          <button className="w-10 h-10 rounded-full border-2 border-dashed border-slate-300 flex items-center justify-center text-slate-400">
                             <Plus className="w-4 h-4" />
                          </button>
                       </div>
                    </div>
                  </div>
                )}

                {activeTab === "backup" && (
                  <div className="space-y-6">
                    <div className="glass-card p-8">
                       <h3 className="text-lg font-display font-bold mb-2 flex items-center gap-2">
                        <Database className="w-5 h-5 text-slate-400" /> Data Preservation
                       </h3>
                       <p className="text-sm text-slate-500 mb-8">Secure your records with regular exports and cloud synchronization.</p>

                       <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div className="p-6 border border-slate-100 rounded-2xl space-y-4">
                             <div className="flex items-center gap-3">
                                <div className="p-2 bg-emerald-50 rounded-xl text-emerald-600">
                                   <RefreshCw className="w-5 h-5" />
                                </div>
                                <div>
                                   <p className="text-sm font-bold text-slate-900">Auto Backup</p>
                                   <p className="text-[10px] text-slate-500 font-medium tracking-tight">Every 24 hours</p>
                                </div>
                             </div>
                             <div className="flex items-center justify-between pt-2">
                                <span className="text-xs font-bold text-slate-400">Status</span>
                                <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-1 rounded-full uppercase tracking-widest">Active</span>
                             </div>
                          </div>

                          <div className="p-6 border border-slate-100 rounded-2xl space-y-4">
                             <div className="flex items-center gap-3">
                                <div className="p-2 bg-blue-50 rounded-xl text-blue-600">
                                   <Cloud className="w-5 h-5" />
                                </div>
                                <div>
                                   <p className="text-sm font-bold text-slate-900">Cloud Sync</p>
                                   <p className="text-[10px] text-slate-500 font-medium tracking-tight">Connected via Firebase</p>
                                </div>
                             </div>
                             <div className="flex items-center justify-between pt-2">
                                <span className="text-xs font-bold text-slate-400">Last Sync</span>
                                <span className="text-[10px] font-bold text-slate-500">2 Hours ago</span>
                             </div>
                          </div>
                       </div>

                       <div className="mt-8 pt-8 border-t border-slate-100">
                          <h4 className="text-sm font-bold text-slate-900 mb-4">Manual Export</h4>
                          <div className="flex flex-wrap gap-4">
                             <button 
                               onClick={() => handleManualExport("json")}
                               className="px-6 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold hover:bg-slate-100 transition-all flex items-center gap-2"
                             >
                                <Download className="w-4 h-4" /> Export as JSON
                             </button>
                             <button 
                               onClick={() => handleManualExport("csv")}
                               className="px-6 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold hover:bg-slate-100 transition-all flex items-center gap-2"
                             >
                                <Download className="w-4 h-4" /> Member CSV Report
                             </button>
                          </div>
                       </div>
                    </div>

                    <div className="p-6 bg-slate-900 rounded-[2rem] text-white">
                       <div className="flex items-center gap-4 mb-4">
                          <div className="p-3 bg-white/10 rounded-2xl">
                             <Database className="w-6 h-6" />
                          </div>
                          <div>
                             <p className="text-lg font-display font-bold">Storage Analytics</p>
                             <p className="text-[10px] text-slate-400 font-mono">DB SIZE: 4.2 MB / 500 MB (0.8%)</p>
                          </div>
                       </div>
                       <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden">
                          <motion.div 
                             initial={{ width: 0 }}
                             animate={{ width: "0.8%" }}
                             className="h-full bg-white"
                          />
                       </div>
                    </div>
                  </div>
                )}
             </motion.div>
           </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
