import { useEffect, useState } from "react";
import { useAuth } from "../hooks/useAuth.tsx";
import { 
  Users, 
  CreditCard, 
  Activity, 
  TrendingUp, 
  ArrowUpRight,
  UserCheck,
  AlertCircle,
  Gift,
  Search,
  Bell
} from "lucide-react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from "recharts";
import { motion } from "motion/react";

interface Stats {
  totalMembers: number;
  activeMembers: number;
  totalRevenue: number;
  attendanceStats: any[];
}

export default function Dashboard() {
  const [stats, setStats] = useState<Stats | null>(null);
  const { token } = useAuth();

  useEffect(() => {
    fetch("/api/dashboard/stats", {
      headers: { Authorization: `Bearer ${token}` }
    })
      .then(res => res.json())
      .then(setStats);
  }, [token]);

  if (!stats) return null;

  const cards = [
    { 
      label: "Total Members", 
      value: stats.totalMembers, 
      icon: Users, 
      color: "from-blue-600 to-indigo-600", 
      trend: "+12%", 
      desc: "24 new this week",
      chart: [40, 70, 45, 90, 65, 80, 95]
    },
    { 
      label: "Active Members", 
      value: stats.activeMembers, 
      icon: UserCheck, 
      color: "from-emerald-600 to-teal-600", 
      trend: "+5%", 
      desc: "Daily peak at 6 PM",
      chart: [60, 40, 80, 50, 70, 40, 90]
    },
    { 
      label: "Total Revenue", 
      value: `$${stats.totalRevenue.toLocaleString()}`, 
      icon: CreditCard, 
      color: "from-slate-800 to-slate-900", 
      trend: "+18%", 
      desc: "Target: $15,000",
      chart: [30, 50, 40, 60, 55, 80, 75]
    },
    { 
      label: "Gym Occupancy", 
      value: "85%", 
      icon: TrendingUp, 
      color: "from-amber-500 to-orange-600", 
      trend: "High", 
      desc: "42 members currently in",
      chart: [20, 50, 30, 70, 40, 60, 50]
    },
  ];

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {cards.map((card, idx) => (
          <motion.div
            key={card.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className="group relative overflow-hidden bg-white rounded-[2rem] p-6 shadow-xl shadow-slate-200/50 border border-slate-100 hover:scale-[1.02] transition-all"
          >
            <div className="relative z-10">
              <div className="flex justify-between items-start mb-6">
                <div className={`p-3 rounded-2xl bg-gradient-to-br ${card.color} text-white shadow-lg shadow-indigo-200`}>
                  <card.icon className="w-6 h-6" />
                </div>
                <div className="flex flex-col items-end">
                  <span className={`text-[10px] font-bold px-2 py-1 rounded-lg ${card.trend.includes('+') ? 'text-emerald-600 bg-emerald-50' : 'text-slate-500 bg-slate-50'}`}>
                    {card.trend}
                  </span>
                </div>
              </div>
              
              <div className="space-y-1">
                <h3 className="text-slate-400 font-bold text-[11px] uppercase tracking-widest">{card.label}</h3>
                <div className="flex items-baseline gap-2">
                  <p className="text-3xl font-display font-bold text-slate-900">{card.value}</p>
                  <p className="text-[10px] text-slate-400 font-medium">{card.desc}</p>
                </div>
              </div>

              {/* Sparkline Mock up */}
              <div className="mt-6 flex items-end gap-1 h-8">
                 {card.chart.map((val, i) => (
                   <div 
                    key={i} 
                    style={{ height: `${val}%` }} 
                    className={`flex-1 rounded-full ${card.color.split(' ')[0].replace('from-', 'bg-')} opacity-20`}
                   />
                 ))}
              </div>
            </div>

            {/* Decorative element */}
            <div className="absolute -right-4 -bottom-4 opacity-[0.03] rotate-12 group-hover:rotate-0 transition-transform duration-500">
               <card.icon size={120} />
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <div className="glass-card p-8">
            <div className="flex justify-between items-center mb-8">
              <div>
                <h3 className="text-lg font-display font-bold">Attendance Analytics</h3>
                <p className="text-sm text-slate-400">Visitor frequency over the last 7 days</p>
              </div>
            </div>
            <div className="h-80 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={stats.attendanceStats}>
                  <defs>
                    <linearGradient id="colorCount" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#0f172a" stopOpacity={0.1}/>
                      <stop offset="95%" stopColor="#0f172a" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis 
                    dataKey="date" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fontSize: 12, fill: '#94a3b8' }} 
                    dy={10}
                  />
                  <YAxis 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fontSize: 12, fill: '#94a3b8' }} 
                  />
                  <Tooltip 
                    contentStyle={{ 
                      borderRadius: '12px', 
                      border: 'none', 
                      boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)',
                      padding: '12px'
                    }} 
                  />
                  <Area 
                    type="monotone" 
                    dataKey="count" 
                    stroke="#0f172a" 
                    strokeWidth={3}
                    fillOpacity={1} 
                    fill="url(#colorCount)" 
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
             <div className="glass-card p-6 bg-white border border-slate-100">
                <div className="flex items-center justify-between mb-6">
                  <h4 className="font-display font-bold text-slate-900 flex items-center gap-2">
                    <Bell className="w-5 h-5 text-amber-500" /> Action Center
                  </h4>
                  <span className="text-[10px] font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full uppercase tracking-wider">3 Urgent</span>
                </div>
                <div className="space-y-4">
                   <div className="flex items-start gap-3 p-3 bg-slate-50 rounded-xl">
                      <AlertCircle className="w-4 h-4 text-red-500 mt-0.5" />
                      <div>
                        <p className="text-xs font-bold text-slate-900">4 Memberships Expiring</p>
                        <p className="text-[10px] text-slate-500 font-medium mt-0.5">Send renewal notifications via SMS</p>
                      </div>
                   </div>
                   <div className="flex items-start gap-3 p-3 bg-slate-50 rounded-xl">
                      <CreditCard className="w-4 h-4 text-emerald-500 mt-0.5" />
                      <div>
                        <p className="text-xs font-bold text-slate-900">Pending Invoices</p>
                        <p className="text-[10px] text-slate-500 font-medium mt-0.5">Total pending: $450.00</p>
                      </div>
                   </div>
                </div>
             </div>

             <div className="glass-card p-6 bg-white border border-slate-100">
                <div className="flex items-center justify-between mb-6">
                  <h4 className="font-display font-bold text-slate-900 flex items-center gap-2">
                    <Gift className="w-5 h-5 text-purple-500" /> Today's Birthdays
                  </h4>
                </div>
                <div className="space-y-3">
                   <div className="flex items-center justify-between p-2 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center text-purple-600 font-bold text-[10px]">MT</div>
                        <span className="text-xs font-bold text-slate-700">Mike Tyson</span>
                      </div>
                      <span className="text-[10px] text-purple-500 font-bold">58 Yrs</span>
                   </div>
                   <p className="text-[10px] text-center text-slate-400 font-medium mt-4 italic">No more birthdays today</p>
                </div>
             </div>
          </div>
        </div>

        <div className="glass-card p-8 bg-slate-900 text-white border-0 shadow-xl shadow-slate-200">
          <h3 className="text-lg font-display font-bold mb-2">Live Status</h3>
          <p className="text-sm text-slate-400 mb-6 font-medium">Currently inside gym</p>
          
          <div className="space-y-4">
             {[1,2,3,4].map((i) => (
                <div key={i} className="flex items-center gap-3 p-3 bg-white/5 rounded-xl border border-white/5">
                  <div className="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center font-bold text-sm">
                    JD
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-bold">John Doe</p>
                    <p className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">Member ID: #M1029</p>
                  </div>
                  <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                </div>
             ))}
          </div>

          <button className="w-full mt-8 py-3 bg-white text-slate-900 rounded-xl font-bold text-sm hover:bg-slate-100 transition-all">
            View Live List
          </button>
        </div>
      </div>
    </div>
  );
}
