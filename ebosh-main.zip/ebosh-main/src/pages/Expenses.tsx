import React, { useState, useEffect } from "react";
import { useAuth } from "../hooks/useAuth.tsx";
import { 
  Receipt, 
  Plus, 
  TrendingUp, 
  ArrowUpRight,
  Calendar,
  Layers,
  Search,
  DollarSign,
  Tag
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner";

interface Expense {
  id: number;
  category: string;
  amount: number;
  description: string;
  date: string;
}

export default function Expenses() {
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(true);
  const { token } = useAuth();

  const [formData, setFormData] = useState({
    category: "Rent",
    amount: "",
    description: "",
    date: new Date().toISOString().split('T')[0]
  });

  const fetchData = async () => {
    try {
      const res = await fetch("/api/expenses", {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (Array.isArray(data)) {
        setExpenses(data);
      } else {
        setExpenses([]);
      }
    } catch (err) {
      toast.error("Failed to load expenses");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [token]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch("/api/expenses", {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(formData)
      });
      if (!res.ok) throw new Error();
      toast.success("Expense recorded");
      setShowForm(false);
      fetchData();
    } catch (err) {
      toast.error("Record failed");
    }
  };

  const totalExpenses = expenses.reduce((acc, curr) => acc + curr.amount, 0);

  return (
    <div className="space-y-8">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-display font-bold tracking-tight text-slate-900">Expense Ledger</h2>
          <p className="text-slate-500 font-medium tracking-tight">Monitor operational costs and gym maintenance outflows</p>
        </div>
        <button 
          onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 bg-slate-900 text-white px-6 py-3 rounded-2xl font-bold shadow-xl shadow-slate-900/10 hover:bg-slate-800 transition-all font-display"
        >
          <Plus className="w-5 h-5" /> {showForm ? "Close Form" : "Record Outflow"}
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="glass-card p-6 bg-red-50 border-red-100">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-red-100/50 rounded-lg text-red-600"><Layers className="w-5 h-5" /></div>
            <ArrowUpRight className="w-5 h-5 text-red-500" />
          </div>
          <p className="text-slate-500 text-sm font-bold uppercase tracking-widest">Total Outflow</p>
          <h3 className="text-3xl font-display font-bold mt-1 text-red-900">${totalExpenses.toLocaleString()}</h3>
        </div>
        
        <div className="glass-card p-6 border-0 bg-slate-900 text-white">
           <div className="flex items-center justify-between mb-4">
             <div className="p-2 bg-white/10 rounded-lg"><TrendingUp className="w-5 h-5" /></div>
           </div>
           <p className="text-slate-400 text-sm font-bold uppercase tracking-widest">Avg daily burn</p>
           <h3 className="text-3xl font-display font-bold mt-1">${(totalExpenses / 30).toFixed(2)}</h3>
        </div>

        <div className="glass-card p-6">
           <div className="flex items-center justify-between mb-4">
             <div className="p-2 bg-slate-100 rounded-lg text-slate-600"><Tag className="w-5 h-5" /></div>
           </div>
           <p className="text-slate-500 text-sm font-bold uppercase tracking-widest">Top category</p>
           <h3 className="text-3xl font-display font-bold mt-1 text-slate-900">Rent & Utils</h3>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
        <AnimatePresence>
          {showForm && (
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <div className="glass-card p-8">
                <h3 className="text-xl font-display font-bold mb-6">New Record</h3>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-500 uppercase pb-1 block">Category</label>
                    <select 
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3"
                      value={formData.category}
                      onChange={(e) => setFormData({...formData, category: e.target.value})}
                    >
                      <option>Rent</option>
                      <option>Electricity</option>
                      <option>Maintenance</option>
                      <option>Supplements</option>
                      <option>Staff Salary</option>
                      <option>Marketing</option>
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-500 uppercase pb-1 block">Amount ($)</label>
                    <input 
                      required
                      type="number"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3"
                      value={formData.amount}
                      onChange={(e) => setFormData({...formData, amount: e.target.value})}
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-500 uppercase pb-1 block">Description</label>
                    <textarea 
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 h-24 resize-none"
                      value={formData.description}
                      onChange={(e) => setFormData({...formData, description: e.target.value})}
                    />
                  </div>
                  <button className="w-full bg-slate-900 text-white font-bold py-4 rounded-xl shadow-xl shadow-slate-900/10 hover:bg-slate-800 transition-all mt-4">
                    Commit To Ledger
                  </button>
                </form>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className={showForm ? "xl:col-span-2" : "xl:col-span-3"}>
          <div className="glass-card overflow-hidden">
            <div className="p-6 border-b border-slate-50 flex items-center justify-between">
               <h3 className="font-display font-bold">Historical Data</h3>
               <Search className="w-4 h-4 text-slate-300" />
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="bg-slate-50/50 text-[10px] uppercase font-bold text-slate-400 tracking-widest">
                  <tr>
                    <th className="px-6 py-4">Category</th>
                    <th className="px-6 py-4">Description</th>
                    <th className="px-6 py-4">Amount</th>
                    <th className="px-6 py-4">Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {expenses.map(ex => (
                    <tr key={ex.id} className="hover:bg-slate-50/50 transition-colors">
                      <td className="px-6 py-4">
                        <span className="text-xs font-bold text-slate-900 bg-slate-100 px-3 py-1 rounded-full">{ex.category}</span>
                      </td>
                      <td className="px-6 py-4 text-xs font-medium text-slate-500">{ex.description || "N/A"}</td>
                      <td className="px-6 py-4 font-mono font-bold text-red-600 text-sm">-${ex.amount.toFixed(2)}</td>
                      <td className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase">{new Date(ex.date).toLocaleDateString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
