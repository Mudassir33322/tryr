import { useState, useEffect } from "react";
import { useAuth } from "../hooks/useAuth.tsx";
import { 
  Search, 
  ShoppingCart, 
  Plus, 
  Minus, 
  Trash2, 
  User, 
  CreditCard, 
  Banknote,
  Receipt,
  X
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner";

interface Product {
  id: number;
  name: string;
  price: number;
  stock: number;
  category: string;
}

interface CartItem extends Product {
  quantity: number;
}

export default function POS() {
  const { token } = useAuth();
  const [products, setProducts] = useState<Product[]>([]);
  const [search, setSearch] = useState("");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [members, setMembers] = useState<any[]>([]);
  const [selectedMemberId, setSelectedMemberId] = useState<number | null>(null);
  const [paymentMethod, setPaymentMethod] = useState("Cash");
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    fetchProducts();
    fetchMembers();
  }, [token]);

  const fetchProducts = async () => {
    const res = await fetch("/api/inventory", {
      headers: { Authorization: `Bearer ${token}` }
    });
    const data = await res.json();
    setProducts(data);
  };

  const fetchMembers = async () => {
    const res = await fetch("/api/members", {
      headers: { Authorization: `Bearer ${token}` }
    });
    const data = await res.json();
    setMembers(data);
  };

  const addToCart = (product: Product) => {
    if (product.stock <= 0) {
      toast.error("Item out of stock");
      return;
    }
    
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        if (existing.quantity >= product.stock) {
          toast.error("Not enough stock");
          return prev;
        }
        return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  const removeFromCart = (productId: number) => {
    setCart(prev => prev.filter(item => item.id !== productId));
  };

  const updateQuantity = (productId: number, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === productId) {
        const newQty = item.quantity + delta;
        if (newQty <= 0) return item;
        if (newQty > item.stock) {
          toast.error("Not enough stock");
          return item;
        }
        return { ...item, quantity: newQty };
      }
      return item;
    }).filter(item => item.quantity > 0));
  };

  const total = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);

  const handleCheckout = async () => {
    if (cart.length === 0) {
      toast.error("Cart is empty");
      return;
    }
    setIsProcessing(true);
    try {
      const res = await fetch("/api/pos/sale", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          member_id: selectedMemberId,
          items: cart,
          payment_method: paymentMethod,
          total_amount: total
        })
      });
      if (res.ok) {
        toast.success("Sale completed successfully!");
        setCart([]);
        setSelectedMemberId(null);
        fetchProducts(); // Refresh stock
      }
    } catch (err) {
      toast.error("Checkout failed");
    } finally {
      setIsProcessing(false);
    }
  };

  const filteredProducts = products.filter(p => 
    p.name.toLowerCase().includes(search.toLowerCase()) || 
    p.category.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="h-[calc(100vh-64px)] flex overflow-hidden">
      {/* Product Selection */}
      <div className="flex-1 p-8 overflow-y-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-display font-bold text-slate-900">Point of Sale</h1>
            <p className="text-sm text-slate-500 font-medium">Scan or select items to sell</p>
          </div>
          <div className="relative w-80">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input 
              type="text"
              placeholder="Search products..."
              className="w-full pl-12 pr-4 py-3 bg-white border border-slate-200 rounded-2xl text-sm focus:ring-2 focus:ring-indigo-500 transition-all shadow-sm"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
          {filteredProducts.map(product => (
            <motion.button
              whileTap={{ scale: 0.95 }}
              key={product.id}
              onClick={() => addToCart(product)}
              className="p-4 bg-white border border-slate-100 rounded-[2rem] text-left hover:shadow-xl hover:shadow-indigo-500/10 hover:border-indigo-100 transition-all group relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 p-3">
                 <span className={`px-2 py-1 rounded text-[8px] font-bold uppercase ${product.stock <= 5 ? 'bg-rose-50 text-rose-500' : 'bg-emerald-50 text-emerald-500'}`}>
                   {product.stock} in stock
                 </span>
              </div>
              <div className="w-12 h-12 bg-slate-50 rounded-2xl mb-4 flex items-center justify-center text-indigo-600 transition-colors group-hover:bg-indigo-50 leading-none">
                <Receipt className="w-6 h-6" />
              </div>
              <p className="font-bold text-slate-900 line-clamp-1 mb-1">{product.name}</p>
              <p className="text-xs text-slate-400 font-medium uppercase tracking-tighter mb-4">{product.category}</p>
              <div className="flex items-center justify-between mt-auto">
                 <p className="text-lg font-bold text-indigo-600">${product.price.toFixed(2)}</p>
                 <div className="w-8 h-8 bg-indigo-600 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all scale-75 group-hover:scale-100">
                    <Plus className="w-4 h-4" />
                 </div>
              </div>
            </motion.button>
          ))}
        </div>
      </div>

      {/* Cart Sidebar */}
      <div className="w-[420px] bg-white border-l border-slate-100 flex flex-col shadow-2xl">
        <div className="p-8 border-b border-slate-50 flex items-center justify-between bg-slate-50/30">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-slate-900 text-white rounded-xl flex items-center justify-center">
              <ShoppingCart className="w-5 h-5" />
            </div>
            <h2 className="text-lg font-bold text-slate-900">Current Order</h2>
          </div>
          <button 
            onClick={() => setCart([])}
            className="text-xs font-bold text-slate-400 hover:text-rose-500 transition-colors"
          >
            Clear All
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-8 space-y-4">
          <AnimatePresence mode="popLayout">
            {cart.map(item => (
              <motion.div 
                layout
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                key={item.id} 
                className="flex items-center gap-4 bg-slate-50 p-4 rounded-2xl border border-transparent hover:border-slate-200 transition-all"
              >
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-slate-900 truncate">{item.name}</p>
                  <p className="text-xs font-bold text-indigo-600">${item.price.toFixed(2)} each</p>
                </div>
                <div className="flex items-center gap-3 bg-white px-2 py-1 rounded-xl shadow-sm border border-slate-100">
                  <button 
                    onClick={() => updateQuantity(item.id, -1)}
                    className="p-1 hover:bg-slate-50 rounded-lg text-slate-400"
                  >
                    <Minus className="w-3 h-3" />
                  </button>
                  <span className="text-xs font-bold w-4 text-center">{item.quantity}</span>
                  <button 
                    onClick={() => updateQuantity(item.id, 1)}
                    className="p-1 hover:bg-slate-50 rounded-lg text-slate-400"
                  >
                    <Plus className="w-3 h-3" />
                  </button>
                </div>
                <button 
                  onClick={() => removeFromCart(item.id)}
                  className="p-2 text-slate-300 hover:text-rose-500 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </motion.div>
            ))}
          </AnimatePresence>
          {cart.length === 0 && (
            <div className="h-full flex flex-col items-center justify-center text-center opacity-30 select-none">
              <ShoppingCart className="w-16 h-16 mb-4" />
              <p className="font-bold uppercase tracking-widest text-xs">Your cart is empty</p>
              <p className="text-[10px] uppercase font-bold mt-1">Add products to start a sale</p>
            </div>
          )}
        </div>

        <div className="p-8 bg-slate-50/50 border-t border-slate-100 space-y-6">
          <div className="space-y-4">
             <div className="flex items-center justify-between text-sm">
                <span className="font-bold text-slate-400">Customer (Optional)</span>
                <User className="w-4 h-4 text-slate-400" />
             </div>
             <select 
               className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-xs font-bold focus:ring-2 focus:ring-indigo-500 outline-none"
               value={selectedMemberId || ""}
               onChange={(e) => setSelectedMemberId(e.target.value ? parseInt(e.target.value) : null)}
             >
               <option value="">Guest Customer</option>
               {members.map(m => (
                 <option key={m.id} value={m.id}>{m.name} ({m.member_id})</option>
               ))}
             </select>
          </div>

          <div className="space-y-4">
             <span className="text-xs font-bold text-slate-400 uppercase tracking-widest block">Payment Method</span>
             <div className="grid grid-cols-2 gap-3">
                <button 
                   onClick={() => setPaymentMethod("Cash")}
                   className={`p-4 rounded-2xl border-2 flex flex-col items-center gap-2 transition-all ${paymentMethod === "Cash" ? 'border-slate-900 bg-white shadow-lg' : 'border-transparent bg-white/50 text-slate-400 opacity-60'}`}
                >
                   <Banknote className="w-6 h-6" />
                   <span className="text-[10px] font-bold uppercase tracking-tighter">Cash</span>
                </button>
                <button 
                   onClick={() => setPaymentMethod("Card")}
                   className={`p-4 rounded-2xl border-2 flex flex-col items-center gap-2 transition-all ${paymentMethod === "Card" ? 'border-indigo-600 bg-white shadow-lg' : 'border-transparent bg-white/50 text-slate-400 opacity-60'}`}
                >
                   <CreditCard className="w-6 h-6" />
                   <span className="text-[10px] font-bold uppercase tracking-tighter">Card</span>
                </button>
             </div>
          </div>

          <div className="pt-4 border-t border-slate-200 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-slate-400 font-bold uppercase text-xs">Total Amount</span>
              <span className="text-3xl font-display font-bold text-slate-900">${total.toFixed(2)}</span>
            </div>
            <button 
              disabled={isProcessing || cart.length === 0}
              onClick={handleCheckout}
              className="w-full py-5 bg-slate-900 text-white rounded-[1.5rem] font-bold text-lg hover:bg-slate-800 transition-all flex items-center justify-center gap-3 shadow-2xl shadow-slate-900/10 disabled:opacity-50 disabled:cursor-not-allowed group"
            >
              {isProcessing ? 'Processing...' : 'Complete Sale'}
              <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function ArrowRight(props: any) {
  return (
    <svg 
      {...props} 
      xmlns="http://www.w3.org/2000/svg" 
      width="24" 
      height="24" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
    >
      <path d="M5 12h14" />
      <path d="m12 5 7 7-7 7" />
    </svg>
  );
}
