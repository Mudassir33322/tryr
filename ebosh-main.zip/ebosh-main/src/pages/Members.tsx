import React, { useEffect, useState } from "react";
import { useAuth } from "../hooks/useAuth.tsx";
import { QRCodeSVG } from "qrcode.react";
import { 
  Search, 
  UserPlus, 
  Download, 
  Filter,
  MoreVertical,
  Mail,
  Phone,
  Calendar,
  ShieldCheck,
  Users,
  Award,
  TrendingUp,
  CreditCard,
  Printer,
  QrCode,
  X,
  ArrowRight
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner";

interface Member {
  id: number;
  member_id: string;
  name: string;
  father_name?: string;
  cnic?: string;
  address?: string;
  whatsapp?: string;
  email: string;
  phone: string;
  plan_name: string;
  trainer_name?: string;
  trainer_id?: number;
  membership_start: string;
  membership_end: string;
  is_active: boolean;
  bmi?: number;
  height?: number;
  weight?: number;
  emergency_contact?: string;
  notes?: string;
}

interface Trainer {
  id: number;
  name: string;
}

interface Plan {
  id: number;
  name: string;
}

export default function Members() {
  const [members, setMembers] = useState<Member[]>([]);
  const [trainers, setTrainers] = useState<Trainer[]>([]);
  const [plans, setPlans] = useState<Plan[]>([]);
  const [search, setSearch] = useState("");
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedMember, setSelectedMember] = useState<Member | null>(null);
  const [showMemberCard, setShowMemberCard] = useState(false);
  const [activeProfileTab, setActiveProfileTab] = useState<"performance" | "attendance" | "identity">("performance");
  const [attendanceLog, setAttendanceLog] = useState<any[]>([]);
  
  const [newMember, setNewMember] = useState({
     name: "",
     father_name: "",
     cnic: "",
     address: "",
     whatsapp: "",
     email: "",
     phone: "",
     gender: "male",
     plan_id: "1",
     trainer_id: "",
     membership_start: new Date().toISOString().split('T')[0],
     membership_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
     height: "",
     weight: "",
     emergency_contact: "",
     notes: ""
  });
  const { token } = useAuth();

  const fetchData = async () => {
    try {
      const [memRes, trainRes, planRes] = await Promise.all([
        fetch("/api/members", { headers: { Authorization: `Bearer ${token}` } }),
        fetch("/api/trainers", { headers: { Authorization: `Bearer ${token}` } }),
        fetch("/api/plans", { headers: { Authorization: `Bearer ${token}` } })
      ]);
      
      if (!memRes.ok || !trainRes.ok || !planRes.ok) {
        throw new Error("Failed to fetch data from server");
      }

      const memData = await memRes.json();
      const trainData = await trainRes.json();
      const planData = await planRes.json();
      
      if (Array.isArray(memData)) setMembers(memData);
      if (Array.isArray(trainData)) setTrainers(trainData);
      if (Array.isArray(planData)) {
        setPlans(planData);
        if (planData.length > 0 && !newMember.plan_id) {
           setNewMember(prev => ({...prev, plan_id: planData[0].id.toString()}));
        }
      }
    } catch (err) {
      toast.error("Fetch failed: Could not synchronize with database");
    }
  };

  useEffect(() => {
    fetchData();
  }, [token]);

  useEffect(() => {
    if (selectedMember && activeProfileTab === "attendance") {
      fetch(`/api/members/${selectedMember.id}/attendance`, {
        headers: { Authorization: `Bearer ${token}` }
      })
      .then(res => res.json())
      .then(data => setAttendanceLog(data))
      .catch(err => toast.error("Failed to load attendance history"));
    }
  }, [selectedMember, activeProfileTab, token]);

  const handleAddMember = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch("/api/members", {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(newMember)
      });
      
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Failed to add member");
      }

      toast.success("Member added successfully!");
      setShowAddModal(false);
      fetchData();
      
      // Automatically show the card for the newly created member
      setSelectedMember(data);
      setShowMemberCard(true);
    } catch (err: any) {
      toast.error(err.message || "Failed to add member");
    }
  };

  const handleExport = async () => {
    const response = await fetch("/api/reports/export/members", {
      headers: { Authorization: `Bearer ${token}` }
    });
    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'members_report.xlsx';
    a.click();
  };

  const filteredMembers = members.filter(m => 
    m.name.toLowerCase().includes(search.toLowerCase()) || 
    m.member_id.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-display font-bold">Member Directory</h2>
          <p className="text-slate-500">Manage {members.length} registered athletes</p>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={handleExport}
            className="flex items-center gap-2 bg-white text-slate-700 px-4 py-2.5 rounded-xl font-bold border border-slate-200 hover:bg-slate-50 transition-all"
          >
            <Download className="w-4 h-4" /> Export Excel
          </button>
          <button 
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 bg-slate-900 text-white px-5 py-2.5 rounded-xl font-bold shadow-lg shadow-slate-900/10 hover:bg-slate-800 transition-all"
          >
            <UserPlus className="w-4 h-4" /> New Member
          </button>
        </div>
      </div>

      <AnimatePresence>
        {showAddModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md">
             <motion.div 
               initial={{ opacity: 0, scale: 0.95, y: 20 }}
               animate={{ opacity: 1, scale: 1, y: 0 }}
               exit={{ opacity: 0, scale: 0.95, y: 20 }}
               className="bg-white rounded-[3rem] shadow-[0_32px_64px_-12px_rgba(0,0,0,0.2)] w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col"
             >
                <div className="p-8 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
                  <div>
                    <h3 className="text-3xl font-display font-bold text-slate-900">Member Registration</h3>
                    <p className="text-slate-500 font-medium">Provision a new enterprise gym account</p>
                  </div>
                  <button 
                    onClick={() => setShowAddModal(false)} 
                    className="p-4 hover:bg-white rounded-2xl transition-all text-slate-300 hover:text-slate-900"
                  >
                     <X className="w-8 h-8" />
                  </button>
                </div>

                <form onSubmit={handleAddMember} className="flex-1 overflow-y-auto p-10 space-y-8 scrollbar-thin">
                  {/* Basic Info */}
                  <div className="space-y-4">
                    <h4 className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest bg-indigo-50 w-fit px-3 py-1 rounded-full">Section I: Identity</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-400 uppercase tracking-wider ml-1">Full Name</label>
                        <input required className="form-input-pro" placeholder="e.g. John Wick" value={newMember.name} onChange={(e) => setNewMember({...newMember, name: e.target.value})} />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-400 uppercase tracking-wider ml-1">Father's Name</label>
                        <input className="form-input-pro" placeholder="e.g. Robert Wick" value={newMember.father_name} onChange={(e) => setNewMember({...newMember, father_name: e.target.value})} />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-400 uppercase tracking-wider ml-1">CNIC / ID Number</label>
                        <input className="form-input-pro" placeholder="42201-XXXXXXX-X" value={newMember.cnic} onChange={(e) => setNewMember({...newMember, cnic: e.target.value})} />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-400 uppercase tracking-wider ml-1">Gender</label>
                        <select className="form-input-pro" value={newMember.gender} onChange={(e) => setNewMember({...newMember, gender: e.target.value})}>
                          <option value="male">Male</option>
                          <option value="female">Female</option>
                          <option value="other">Other</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  {/* Contact Info */}
                  <div className="space-y-4">
                    <h4 className="text-[10px] font-bold text-emerald-600 uppercase tracking-widest bg-emerald-50 w-fit px-3 py-1 rounded-full">Section II: Contact & Communication</h4>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-400 uppercase tracking-wider ml-1">Mobile Phone</label>
                        <input className="form-input-pro" placeholder="+92 XXX XXXXXXX" value={newMember.phone} onChange={(e) => setNewMember({...newMember, phone: e.target.value})} />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-400 uppercase tracking-wider ml-1">WhatsApp</label>
                        <input className="form-input-pro" placeholder="+92 XXX XXXXXXX" value={newMember.whatsapp} onChange={(e) => setNewMember({...newMember, whatsapp: e.target.value})} />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-400 uppercase tracking-wider ml-1">Email Address</label>
                        <input type="email" className="form-input-pro" placeholder="john@example.com" value={newMember.email} onChange={(e) => setNewMember({...newMember, email: e.target.value})} />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-400 uppercase tracking-wider ml-1">Residential Address</label>
                      <input className="form-input-pro" placeholder="Flat #, Street #, Area, City" value={newMember.address} onChange={(e) => setNewMember({...newMember, address: e.target.value})} />
                    </div>
                  </div>

                  {/* Fitness Info */}
                  <div className="space-y-4">
                    <h4 className="text-[10px] font-bold text-amber-600 uppercase tracking-widest bg-amber-50 w-fit px-3 py-1 rounded-full">Section III: Fitness Profile</h4>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-400 uppercase tracking-wider ml-1">Height (cm)</label>
                        <input type="number" className="form-input-pro" value={newMember.height} onChange={(e) => setNewMember({...newMember, height: e.target.value})} />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-400 uppercase tracking-wider ml-1">Weight (kg)</label>
                        <input type="number" className="form-input-pro" value={newMember.weight} onChange={(e) => setNewMember({...newMember, weight: e.target.value})} />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-400 uppercase tracking-wider ml-1">Membership Plan</label>
                        <select className="form-input-pro font-bold" value={newMember.plan_id} onChange={(e) => setNewMember({...newMember, plan_id: e.target.value})}>
                          {plans.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                        </select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-400 uppercase tracking-wider ml-1">Start Date</label>
                        <input type="date" className="form-input-pro" value={newMember.membership_start} onChange={(e) => setNewMember({...newMember, membership_start: e.target.value})} />
                      </div>
                    </div>
                  </div>

                  {/* Emergency */}
                  <div className="space-y-4">
                    <h4 className="text-[10px] font-bold text-rose-600 uppercase tracking-widest bg-rose-50 w-fit px-3 py-1 rounded-full">Section IV: Emergency & Notes</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-400 uppercase tracking-wider ml-1">Emergency Contact Info</label>
                        <textarea className="form-input-pro min-h-[100px] py-4" placeholder="Contact Person & Phone Number" value={newMember.emergency_contact} onChange={(e) => setNewMember({...newMember, emergency_contact: e.target.value})} />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-400 uppercase tracking-wider ml-1">Internal Notes</label>
                        <textarea className="form-input-pro min-h-[100px] py-4" placeholder="Injuries, medical conditions, goals..." value={newMember.notes} onChange={(e) => setNewMember({...newMember, notes: e.target.value})} />
                      </div>
                    </div>
                  </div>
                </form>

                <div className="p-8 border-t border-slate-100 bg-slate-50/50 flex gap-4">
                   <button 
                     onClick={() => setShowAddModal(false)}
                     className="flex-1 py-5 bg-white border border-slate-200 text-slate-600 rounded-[2rem] font-bold hover:bg-slate-100 transition-all uppercase tracking-widest text-xs"
                   >
                     Discard
                   </button>
                   <button 
                     onClick={handleAddMember}
                     className="flex-[2] py-5 bg-slate-900 text-white rounded-[2rem] font-bold hover:bg-slate-800 transition-all shadow-2xl shadow-slate-900/20 uppercase tracking-widest text-xs flex items-center justify-center gap-3"
                   >
                     Complete Provisioning <ArrowRight className="w-5 h-5" />
                   </button>
                </div>
             </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {selectedMember && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md">
            <motion.div 
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 50 }}
              className="bg-white rounded-[2rem] shadow-2xl w-full max-w-5xl h-[85vh] overflow-hidden flex flex-col md:flex-row"
            >
              {/* Profile Sidebar */}
              <div className="w-full md:w-80 bg-slate-900 text-white p-8 flex flex-col">
                <div className="flex-1">
                   <div className="relative group cursor-pointer" onClick={() => setShowMemberCard(true)}>
                     <div className="w-24 h-24 rounded-[2rem] bg-gradient-to-br from-indigo-500 to-purple-500 mb-6 flex items-center justify-center text-3xl font-display font-bold shadow-xl shadow-indigo-500/20">
                       {selectedMember.name.charAt(0)}
                     </div>
                     <div className="absolute -bottom-2 -right-2 bg-white p-2 rounded-xl shadow-lg group-hover:scale-110 transition-all">
                       <QRCodeSVG 
                         value={selectedMember.member_id}
                         size={32}
                         level="L"
                       />
                     </div>
                   </div>
                   <h3 className="text-2xl font-display font-bold mt-2">{selectedMember.name}</h3>
                   <p className="text-slate-400 font-medium text-xs uppercase tracking-tighter mt-1">{selectedMember.member_id}</p>
                   
                   <div className="mt-8 space-y-4">
                      <div className="flex items-center gap-3 text-slate-300">
                         <ShieldCheck className="w-4 h-4" />
                         <span className="text-sm font-medium">{selectedMember.plan_name}</span>
                      </div>
                      <div className="flex items-center gap-3 text-slate-300">
                         <Calendar className="w-4 h-4" />
                         <span className="text-sm font-medium">Expires: {new Date(selectedMember.membership_end).toLocaleDateString()}</span>
                      </div>
                      {selectedMember.trainer_name && (
                        <div className="flex items-center gap-3 text-emerald-400">
                           <Award className="w-4 h-4" />
                           <span className="text-sm font-bold">Coach: {selectedMember.trainer_name}</span>
                        </div>
                      )}
                      <button 
                        onClick={() => setShowMemberCard(true)}
                        className="w-full mt-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold transition-all flex items-center justify-center gap-2"
                      >
                        <CreditCard className="w-4 h-4" /> Member Card
                      </button>
                   </div>
                </div>
                
                <button 
                  onClick={() => {
                    setSelectedMember(null);
                    setActiveProfileTab("performance");
                  }}
                  className="w-full py-4 bg-white/10 hover:bg-white/20 rounded-2xl font-bold transition-all"
                >
                  Close Profile
                </button>
              </div>

              {/* Main Profile Tabs */}
              <div className="flex-1 p-10 overflow-y-auto">
                  <div className="flex items-center gap-8 border-b border-slate-100 mb-8">
                     <button 
                        onClick={() => setActiveProfileTab("performance")}
                        className={`text-sm font-bold pb-4 transition-all ${activeProfileTab === "performance" ? "text-slate-900 border-b-2 border-slate-900" : "text-slate-400"}`}
                     >
                       Performance
                     </button>
                     <button 
                        onClick={() => setActiveProfileTab("attendance")}
                        className={`text-sm font-bold pb-4 transition-all ${activeProfileTab === "attendance" ? "text-slate-900 border-b-2 border-slate-900" : "text-slate-400"}`}
                     >
                       Attendance Log
                     </button>
                     <button 
                        onClick={() => setActiveProfileTab("identity")}
                        className={`text-sm font-bold pb-4 transition-all ${activeProfileTab === "identity" ? "text-slate-900 border-b-2 border-slate-900" : "text-slate-400"}`}
                     >
                       Identity & Details
                     </button>
                     <button className="text-sm font-bold text-slate-300 pb-4 cursor-not-allowed">Workout Plan</button>
                     <button className="text-sm font-bold text-slate-300 pb-4 cursor-not-allowed">Nutrition</button>
                  </div>

                  {activeProfileTab === "identity" ? (
                    <div className="space-y-8 animate-in fade-in slide-in-from-left-4">
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                          <div className="space-y-4">
                             <h5 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest border-b border-slate-100 pb-2">Family & National Identity</h5>
                             <div className="grid grid-cols-2 gap-4">
                                <div>
                                   <p className="text-[10px] font-bold text-slate-400 uppercase">Father's Name</p>
                                   <p className="text-sm font-bold text-slate-900">{selectedMember.father_name || 'Not Provided'}</p>
                                </div>
                                <div>
                                   <p className="text-[10px] font-bold text-slate-400 uppercase">CNIC / ID</p>
                                   <p className="text-sm font-mono font-bold text-slate-900">{selectedMember.cnic || 'Not Provided'}</p>
                                </div>
                             </div>
                          </div>
                          <div className="space-y-4">
                             <h5 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest border-b border-slate-100 pb-2">Digital Continuity</h5>
                             <div className="grid grid-cols-2 gap-4">
                                <div>
                                   <p className="text-[10px] font-bold text-slate-400 uppercase">WhatsApp</p>
                                   <p className="text-sm font-bold text-slate-900">{selectedMember.whatsapp || 'Not Provided'}</p>
                                </div>
                                <div>
                                   <p className="text-[10px] font-bold text-slate-400 uppercase">Email Sync</p>
                                   <p className="text-sm font-bold text-emerald-500 flex items-center gap-1">
                                     <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full" /> Verified
                                   </p>
                                </div>
                             </div>
                          </div>
                       </div>

                       <div className="space-y-4">
                          <h5 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest border-b border-slate-100 pb-2">Location & Logistics</h5>
                          <div className="p-4 bg-slate-50 rounded-2xl">
                             <p className="text-[10px] font-bold text-slate-400 uppercase">Permanent Address</p>
                             <p className="text-sm font-medium text-slate-700 mt-1">{selectedMember.address || 'No address registered'}</p>
                          </div>
                       </div>

                       <div className="grid grid-cols-3 gap-6">
                          <div className="p-4 bg-slate-50 rounded-2xl">
                             <p className="text-[10px] font-bold text-slate-400 uppercase">Height</p>
                             <p className="text-lg font-bold text-slate-900">{selectedMember.height || '-'} <span className="text-xs font-medium text-slate-400">cm</span></p>
                          </div>
                          <div className="p-4 bg-slate-50 rounded-2xl">
                             <p className="text-[10px] font-bold text-slate-400 uppercase">Weight</p>
                             <p className="text-lg font-bold text-slate-900">{selectedMember.weight || '-'} <span className="text-xs font-medium text-slate-400">kg</span></p>
                          </div>
                          <div className="p-4 bg-slate-50 rounded-2xl">
                             <p className="text-[10px] font-bold text-slate-400 uppercase">BMI Score</p>
                             <p className="text-lg font-bold text-indigo-600">{selectedMember.bmi || 'N/A'}</p>
                          </div>
                       </div>
                       
                       <div className="space-y-4">
                          <h5 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest border-b border-slate-100 pb-2">Medical & Safety</h5>
                          <div className="p-4 bg-rose-50 rounded-2xl border border-rose-100">
                             <p className="text-[10px] font-bold text-rose-500 uppercase">Emergency Protocol</p>
                             <p className="text-sm font-bold text-rose-900 mt-1 whitespace-pre-wrap">{selectedMember.emergency_contact || 'No emergency contact specified'}</p>
                          </div>
                       </div>
                    </div>
                  ) : activeProfileTab === "performance" ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                       <div className="glass-card p-6 bg-slate-50 border-0">
                          <h4 className="font-bold text-slate-900 mb-4 flex items-center gap-2">
                            <TrendingUp className="w-4 h-4 text-emerald-500" /> BMI Tracking
                          </h4>
                          <div className="h-40 bg-white rounded-2xl flex items-center justify-center text-slate-300 font-bold">
                            Coming Soon
                          </div>
                       </div>
                       <div className="glass-card p-6 bg-slate-50 border-0">
                          <h4 className="font-bold text-slate-900 mb-4">Quick Stats</h4>
                          <div className="space-y-3">
                             <div className="bg-white p-3 rounded-xl flex items-center justify-between">
                                 <span className="text-xs font-bold text-slate-500">Days Active</span>
                                 <span className="text-[10px] bg-slate-100 px-2 py-1 rounded font-bold uppercase">24 Days</span>
                             </div>
                             <div className="bg-white p-3 rounded-xl flex items-center justify-between">
                                 <span className="text-xs font-bold text-slate-500">Avg. Duration</span>
                                 <span className="text-[10px] bg-slate-100 px-2 py-1 rounded font-bold uppercase">75 Mins</span>
                             </div>
                          </div>
                       </div>

                       <div className="col-span-2">
                          <h4 className="font-bold text-slate-900 mb-4">Current Training Focus</h4>
                          <div className="grid grid-cols-3 gap-4">
                             <div className="p-4 bg-emerald-50 rounded-2xl">
                                <p className="text-[10px] text-emerald-600 font-bold uppercase">Endurance</p>
                                <p className="text-lg font-bold text-emerald-900">85%</p>
                             </div>
                             <div className="p-4 bg-blue-50 rounded-2xl">
                                <p className="text-[10px] text-blue-600 font-bold uppercase">Strength</p>
                                <p className="text-lg font-bold text-blue-900">42%</p>
                             </div>
                             <div className="p-4 bg-purple-50 rounded-2xl">
                                <p className="text-[10px] text-purple-600 font-bold uppercase">Mobility</p>
                                <p className="text-lg font-bold text-purple-900">High</p>
                             </div>
                          </div>
                       </div>
                    </div>
                  ) : (
                    <div className="space-y-4">
                       <h4 className="font-bold text-slate-900 mb-4">Complete Attendance History</h4>
                       <div className="bg-slate-50 rounded-3xl overflow-hidden border border-slate-100">
                          <table className="w-full text-left">
                             <thead className="bg-white border-b border-slate-100">
                                <tr>
                                   <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase">Date</th>
                                   <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase">Check In</th>
                                   <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase">Check Out</th>
                                   <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase text-right">Status</th>
                                </tr>
                             </thead>
                             <tbody className="divide-y divide-slate-100">
                                {attendanceLog.length > 0 ? attendanceLog.map((log) => (
                                   <tr key={log.id} className="hover:bg-white transition-colors">
                                      <td className="px-6 py-4 text-sm font-bold text-slate-700">{new Date(log.date).toLocaleDateString()}</td>
                                      <td className="px-6 py-4 text-sm text-slate-500 font-medium">
                                        {log.check_in ? new Date(log.check_in).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : "-"}
                                      </td>
                                      <td className="px-6 py-4 text-sm text-slate-500 font-medium">
                                        {log.check_out ? new Date(log.check_out).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : (
                                          <span className="text-amber-500 italic">In Gym</span>
                                        )}
                                      </td>
                                      <td className="px-6 py-4 text-right">
                                         <span className="px-2 py-1 bg-white border border-slate-200 rounded text-[10px] font-bold uppercase text-slate-400">
                                           Verified
                                         </span>
                                      </td>
                                   </tr>
                                )) : (
                                  <tr>
                                    <td colSpan={4} className="px-6 py-12 text-center text-slate-400 font-medium italic">
                                      No attendance records found for this member.
                                    </td>
                                  </tr>
                                )}
                             </tbody>
                          </table>
                       </div>
                    </div>
                  )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <div className="flex flex-col lg:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search by name or member ID..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-white border border-slate-200 rounded-2xl py-3 pl-12 pr-4 outline-none focus:ring-2 focus:ring-slate-900/5 focus:border-slate-900 transition-all"
          />
        </div>
        <button className="px-4 py-3 bg-white border border-slate-200 rounded-2xl text-slate-600 flex items-center gap-2 hover:bg-slate-50">
          <Filter className="w-5 h-5" /> Filters
        </button>
      </div>

      <div className="glass-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50 border-b border-slate-100">
                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Member Info</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Member ID</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Status</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Plan</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Join Date</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Contact</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filteredMembers.map((member, idx) => (
                <motion.tr 
                  key={member.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: idx * 0.05 }}
                  className="hover:bg-slate-50/50 transition-colors group"
                >
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center font-bold text-slate-500 text-xs shadow-inner">
                        {member.name.charAt(0)}
                      </div>
                      <div>
                        <p className="font-bold text-slate-900 group-hover:text-slate-900">{member.name}</p>
                        <p className="text-xs text-slate-400 font-medium">{member.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm font-mono font-bold text-indigo-600 bg-indigo-50 px-3 py-1.5 rounded-xl border border-indigo-100">
                      {member.member_id}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold ${
                      member.is_active ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'
                    }`}>
                      <div className={`w-1.5 h-1.5 rounded-full ${member.is_active ? 'bg-emerald-500' : 'bg-red-500'}`} />
                      {member.is_active ? 'Active' : 'Expired'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                       <ShieldCheck className="w-4 h-4 text-slate-400" />
                       <span className="text-sm font-semibold text-slate-600">{member.plan_name || 'N/A'}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2 text-xs font-bold text-slate-500 bg-slate-100/50 px-2 py-1 rounded w-fit">
                       <Calendar className="w-3 h-3" />
                       {new Date(member.membership_start).toLocaleDateString()}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 text-xs text-slate-400">
                        <Mail className="w-3 h-3" />
                        <span className="truncate max-w-[150px]">{member.email}</span>
                      </div>
                      <div className="flex items-center gap-2 text-xs text-slate-400">
                        <Phone className="w-3 h-3" />
                        <span>{member.phone}</span>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button 
                      onClick={() => setSelectedMember(member)}
                      className="p-2 hover:bg-slate-900 hover:text-white rounded-lg text-slate-400 transition-all font-bold text-xs flex items-center gap-2"
                    >
                      View Profile
                    </button>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
        
        {filteredMembers.length === 0 && (
          <div className="py-20 text-center bg-white">
            <Users className="w-16 h-16 text-slate-100 mx-auto mb-4" />
            <p className="text-slate-400 font-medium">No members found matching your search</p>
          </div>
        )}
      </div>

      <div className="flex items-center justify-between text-sm text-slate-400 font-medium px-2">
        <p>Showing {filteredMembers.length} of {members.length} members</p>
        <div className="flex items-center gap-2">
           <button className="px-4 py-2 border border-slate-200 rounded-xl hover:bg-white transition-all disabled:opacity-50" disabled>Previous</button>
           <button className="px-4 py-2 border border-slate-200 rounded-xl hover:bg-white transition-all disabled:opacity-50" disabled>Next</button>
        </div>
      </div>

      <AnimatePresence>
        {showMemberCard && selectedMember && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-lg">
             <motion.div 
               initial={{ opacity: 0, scale: 0.9 }}
               animate={{ opacity: 1, scale: 1 }}
               exit={{ opacity: 0, scale: 0.9 }}
               className="bg-white rounded-[2.5rem] p-10 max-w-md w-full shadow-2xl relative overflow-hidden"
             >
                {/* Print styles */}
                <style>
                  {`
                    @media print {
                      body * { visibility: hidden; }
                      .printable-card, .printable-card * { visibility: visible; }
                      .printable-card { 
                        position: absolute; 
                        left: 0; 
                        top: 0; 
                        width: 100%;
                        height: auto;
                        padding: 0;
                        box-shadow: none;
                        border: none;
                      }
                      .no-print { display: none !important; }
                    }
                  `}
                </style>

                <div className="printable-card space-y-8">
                   {/* Front Side */}
                   <div className="bg-slate-900 rounded-[2.5rem] p-8 text-white relative overflow-hidden aspect-[1.6/1] shadow-2xl border border-white/5 group">
                      <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl group-hover:bg-indigo-500/20 transition-all" />
                      <div className="absolute bottom-0 left-0 w-48 h-48 bg-purple-500/10 rounded-full translate-y-1/2 -translate-x-1/2 blur-2xl group-hover:bg-purple-500/20 transition-all" />
                      
                      <div className="relative z-10 h-full flex flex-col justify-between">
                         <div className="flex justify-between items-start">
                            <div>
                               <h4 className="text-3xl font-display font-black tracking-tighter italic text-transparent bg-clip-text bg-gradient-to-r from-white to-slate-400">TITAN GYM</h4>
                               <p className="text-[10px] text-indigo-400 font-bold uppercase tracking-[0.3em] mt-1 ml-1">Elite Performance Center</p>
                            </div>
                            <div className="bg-white/10 backdrop-blur-xl px-4 py-2 rounded-2xl border border-white/10">
                               <p className="text-[10px] font-black uppercase text-indigo-300">Member Status</p>
                               <p className="text-xs font-bold text-white uppercase">{selectedMember.plan_name}</p>
                            </div>
                         </div>

                         <div className="flex items-end justify-between">
                            <div className="space-y-4">
                               <div className="w-16 h-16 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center border border-white/10">
                                  <Users className="w-8 h-8 text-white" />
                               </div>
                               <div>
                                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Athlete Name</p>
                                  <p className="text-2xl font-display font-bold leading-none mt-1">{selectedMember.name}</p>
                               </div>
                            </div>
                            <div className="text-right">
                               <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Exclusive ID</p>
                               <p className="text-xl font-mono font-bold text-indigo-400">{selectedMember.member_id}</p>
                            </div>
                         </div>
                      </div>
                   </div>

                   {/* Back Side / Details */}
                   <div className="bg-white rounded-[2.5rem] p-8 border-2 border-slate-100 aspect-[1.6/1] flex flex-col justify-between shadow-xl">
                      <div className="flex justify-between items-center px-2">
                         <div className="bg-slate-100 p-4 rounded-3xl">
                            <QRCodeSVG 
                              value={selectedMember.member_id}
                              size={80}
                              level="H"
                              includeMargin={false}
                              fgColor="#0f172a"
                            />
                         </div>
                         <div className="text-right space-y-1">
                            <p className="text-xs font-bold text-slate-900">Valid Until</p>
                            <p className="text-xl font-black text-slate-900">{new Date(selectedMember.membership_end).toLocaleDateString()}</p>
                            <p className="text-[10px] text-slate-400 font-bold uppercase">Membership Period</p>
                         </div>
                      </div>

                      <div className="space-y-4">
                        <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 grid grid-cols-2 gap-4">
                           <div>
                              <p className="text-[10px] text-slate-400 font-bold uppercase">Facility Access</p>
                              <p className="text-xs font-bold text-slate-900">24/7 Premium Access</p>
                           </div>
                           <div>
                              <p className="text-[10px] text-slate-400 font-bold uppercase">Guest Program</p>
                              <p className="text-xs font-bold text-slate-900">1 Guest/Month Included</p>
                           </div>
                        </div>
                        <p className="text-[9px] text-slate-400 text-center font-medium leading-relaxed">
                          This card remains property of TITAN GYM. Use is subject to terms. Please notify immediately if lost or stolen. Non-transferable.
                        </p>
                      </div>
                   </div>
                </div>

                <div className="mt-8 flex gap-4 no-print">
                   <button 
                    onClick={() => window.print()}
                    className="flex-1 py-4 bg-slate-900 text-white rounded-2xl font-bold flex items-center justify-center gap-2 hover:scale-[1.02] transition-all"
                   >
                     <Printer className="w-4 h-4" /> Print Card
                   </button>
                   <button 
                    onClick={() => setShowMemberCard(false)}
                    className="flex-1 py-4 bg-slate-100 text-slate-600 rounded-2xl font-bold"
                   >
                     Close
                   </button>
                </div>
             </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
