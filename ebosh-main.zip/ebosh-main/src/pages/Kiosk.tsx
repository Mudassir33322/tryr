import React, { useState, useEffect, useRef } from "react";
import { useAuth } from "../hooks/useAuth.tsx";
import { 
  QrCode, 
  UserCheck, 
  UserMinus, 
  AlertCircle, 
  Clock, 
  ArrowLeft,
  Scan,
  ShieldAlert
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";

export default function Kiosk() {
  const { token } = useAuth();
  const navigate = useNavigate();
  const [memberCode, setMemberCode] = useState("");
  const [status, setStatus] = useState<"idle" | "success" | "error" | "processing">("idle");
  const [lastScan, setLastScan] = useState<any>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    // Keep focus on the hidden input for barcode scanners
    const timer = setInterval(() => {
      inputRef.current?.focus();
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleScan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!memberCode.trim()) return;

    setStatus("processing");
    try {
      const res = await fetch("/api/attendance/scan", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ member_id_code: memberCode.trim() })
      });

      const data = await res.json();
      if (res.ok) {
        setLastScan(data);
        setStatus("success");
        setMemberCode("");
        setTimeout(() => setStatus("idle"), 5000);
      } else {
        setStatus("error");
        setMemberCode("");
        toast.error(data.error || "Scan failed");
        setTimeout(() => setStatus("idle"), 3000);
      }
    } catch (err) {
      setStatus("error");
      setTimeout(() => setStatus("idle"), 3000);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col font-sans overflow-hidden">
      {/* Kiosk Header */}
      <header className="p-10 flex justify-between items-center bg-white/5 backdrop-blur-xl border-b border-white/5">
        <div className="flex items-center gap-6">
          <div className="w-16 h-16 bg-white rounded-3xl flex items-center justify-center text-slate-950 shadow-2xl shadow-white/5">
            <QrCode className="w-8 h-8" />
          </div>
          <div>
            <h1 className="text-4xl font-display font-black tracking-tighter uppercase italic">Titan Kiosk</h1>
            <p className="text-slate-500 font-bold tracking-widest text-xs uppercase mt-1">Reception Attendance Node #01</p>
          </div>
        </div>
        <div className="flex items-center gap-8">
           <div className="text-right">
              <p className="text-4xl font-mono font-bold">{new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">{new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })}</p>
           </div>
           <button 
             onClick={() => navigate("/")}
             className="w-16 h-16 bg-white/5 hover:bg-white/10 rounded-3xl flex items-center justify-center transition-all border border-white/5"
           >
             <ArrowLeft className="w-6 h-6" />
           </button>
        </div>
      </header>

      {/* Main Kiosk Area */}
      <main className="flex-1 flex flex-col items-center justify-center p-10 relative">
        {/* Scanning Animation Background */}
        <div className="absolute inset-0 opacity-20 pointer-events-none overflow-hidden">
           <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] border border-white/10 rounded-full animate-ping" />
           <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] border border-white/5 rounded-full animate-[ping_3s_infinite]" />
        </div>

        <div className="z-10 w-full max-w-4xl">
           <AnimatePresence mode="wait">
             {status === "idle" || status === "processing" ? (
               <motion.div 
                 key="idle"
                 initial={{ opacity: 0, scale: 0.9 }}
                 animate={{ opacity: 1, scale: 1 }}
                 exit={{ opacity: 0, scale: 1.1 }}
                 className="flex flex-col items-center gap-12"
               >
                  <div className="relative">
                    <div className="w-64 h-64 rounded-[3rem] border-4 border-slate-800 flex items-center justify-center bg-slate-900 shadow-2xl relative overflow-hidden group">
                       <Scan className="w-24 h-24 text-slate-700 group-hover:text-white transition-all duration-500" />
                       <div className="absolute bottom-0 left-0 right-0 h-1 bg-indigo-500 animate-[scan_2s_infinite]" />
                    </div>
                  </div>

                  <div className="text-center space-y-4">
                     <h2 className="text-5xl font-display font-black text-white">READY TO SCAN</h2>
                     <p className="text-slate-400 text-lg font-medium">Place your membership card under the scanner</p>
                  </div>

                  <form onSubmit={handleScan} className="opacity-0 absolute">
                    <input 
                      ref={inputRef}
                      autoFocus
                      className="bg-transparent border-0 outline-none"
                      value={memberCode}
                      onChange={(e) => setMemberCode(e.target.value)}
                    />
                  </form>

                  <div className="flex gap-4 mt-8">
                     <div className="flex items-center gap-2 px-4 py-2 bg-white/5 rounded-full border border-white/5 text-xs font-bold text-slate-500 uppercase tracking-widest">
                       <Clock className="w-4 h-4" /> 24/7 Monitoring Active
                     </div>
                     <div className="flex items-center gap-2 px-4 py-2 bg-white/5 rounded-full border border-white/5 text-xs font-bold text-slate-500 uppercase tracking-widest">
                       <ShieldAlert className="w-4 h-4" /> Secure Auth Protocol
                     </div>
                  </div>
               </motion.div>
             ) : status === "success" ? (
               <motion.div 
                 key="success"
                 initial={{ opacity: 0, y: 20 }}
                 animate={{ opacity: 1, y: 0 }}
                 exit={{ opacity: 0, y: -20 }}
                 className={`w-full max-w-2xl mx-auto rounded-[3.5rem] p-12 flex flex-col items-center gap-8 ${lastScan.status === 'checked_in' ? 'bg-emerald-500 text-emerald-950' : 'bg-amber-500 text-amber-950'}`}
               >
                  <div className="w-32 h-32 bg-white rounded-full flex items-center justify-center shadow-2xl">
                    {lastScan.status === "checked_in" ? (
                      <UserCheck className="w-16 h-16 text-emerald-600" />
                    ) : (
                      <UserMinus className="w-16 h-16 text-amber-600" />
                    )}
                  </div>
                  <div className="text-center space-y-2">
                     <p className="text-sm font-black uppercase tracking-[0.4em] opacity-60">System Notification</p>
                     <h2 className="text-6xl font-display font-black uppercase tracking-tighter">
                       {lastScan.status === "checked_in" ? "CHECKED IN" : "CHECKED OUT"}
                     </h2>
                  </div>
                  
                  <div className="w-full bg-white/20 backdrop-blur-md rounded-[2.5rem] p-8 border border-white/20">
                     <div className="flex items-center gap-6">
                        <div className="w-24 h-24 rounded-3xl bg-white flex items-center justify-center text-4xl font-display font-black text-slate-900 shadow-xl">
                          {lastScan.member.name.charAt(0)}
                        </div>
                        <div className="flex-1">
                           <p className="text-[10px] font-black uppercase tracking-widest opacity-60">Athlete ID: {lastScan.member.member_id}</p>
                           <h3 className="text-3xl font-display font-bold">{lastScan.member.name}</h3>
                           <p className="text-sm font-bold opacity-80 mt-1 uppercase tracking-tighter">Membership: Active Until {new Date(lastScan.member.membership_end).toLocaleDateString()}</p>
                        </div>
                     </div>
                  </div>

                  <p className="text-xs font-bold uppercase tracking-widest opacity-60">Returning to Idle in 5 Seconds...</p>
               </motion.div>
             ) : (
               <motion.div 
                 key="error"
                 initial={{ opacity: 0, scale: 0.9 }}
                 animate={{ opacity: 1, scale: 1 }}
                 className="flex flex-col items-center gap-8 text-rose-500"
               >
                  <div className="w-32 h-32 bg-rose-500/10 rounded-full flex items-center justify-center border-4 border-rose-500/20">
                    <AlertCircle className="w-16 h-16" />
                  </div>
                  <div className="text-center space-y-4">
                     <h2 className="text-5xl font-display font-black">ACCESS DENIED</h2>
                     <p className="text-rose-400/60 text-lg font-bold uppercase tracking-widest">Invalid Credential or Blocked Account</p>
                  </div>
                  <p className="text-slate-500 text-xs font-bold uppercase tracking-widest animate-pulse">Retrying Interface...</p>
               </motion.div>
             )}
           </AnimatePresence>
        </div>
      </main>

      {/* Kiosk Footer */}
      <footer className="p-10 text-center border-t border-white/5 flex flex-col items-center gap-4">
         <p className="text-slate-500 font-bold uppercase tracking-[0.5em] text-[10px]">Industrial Gym Management Interface v2.4.0</p>
         <div className="flex gap-8 opacity-20">
            <div className="h-1 w-24 bg-white rounded-full" />
            <div className="h-1 w-12 bg-white rounded-full" />
            <div className="h-1 w-32 bg-white rounded-full" />
         </div>
      </footer>

      <style>
        {`
          @keyframes scan {
            0% { transform: translateY(0); opacity: 1; }
            50% { transform: translateY(256px); opacity: 1; }
            100% { transform: translateY(0); opacity: 1; }
          }
        `}
      </style>
    </div>
  );
}
