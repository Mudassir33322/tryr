import knex from "knex";
import path from "path";

const db = knex({
  client: "better-sqlite3",
  connection: {
    filename: "./gym.sqlite",
  },
  useNullAsDefault: true,
});

export async function initDb() {
  const hasUsers = await db.schema.hasTable("users");
  if (!hasUsers) {
    await db.schema.createTable("users", (table) => {
      table.increments("id").primary();
      table.string("name").notNullable();
      table.string("email").unique().notNullable();
      table.string("password").notNullable();
      table.enum("role", ["admin", "staff", "trainer"]).defaultTo("staff");
      table.timestamps(true, true);
    });
  }

  const hasPlans = await db.schema.hasTable("membership_plans");
  if (!hasPlans) {
    await db.schema.createTable("membership_plans", (table) => {
      table.increments("id").primary();
      table.string("name").notNullable();
      table.decimal("price").notNullable();
      table.integer("duration_months").notNullable();
      table.text("description");
      table.timestamps(true, true);
    });
  }

  const hasMembers = await db.schema.hasTable("members");
  if (!hasMembers) {
    await db.schema.createTable("members", (table) => {
      table.increments("id").primary();
      table.string("member_id").unique().notNullable(); // For QR/Barcode
      table.string("name").notNullable();
      table.string("father_name");
      table.string("cnic");
      table.string("address");
      table.string("whatsapp");
      table.string("email").unique();
      table.string("phone");
      table.string("photo_url");
      table.date("dob");
      table.enum("gender", ["male", "female", "other"]);
      table.integer("plan_id").references("id").inTable("membership_plans");
      table.integer("trainer_id").references("id").inTable("trainers").nullable();
      table.date("membership_start");
      table.date("membership_end");
      table.boolean("is_active").defaultTo(true);
      table.decimal("height");
      table.decimal("weight");
      table.decimal("bmi");
      table.text("fitness_goals");
      table.text("emergency_contact");
      table.text("notes");
      table.timestamps(true, true);
    });
  } else {
    // Add missing columns to existing members table
    const columns = [
      { name: "father_name", type: "string" },
      { name: "cnic", type: "string" },
      { name: "address", type: "string" },
      { name: "whatsapp", type: "string" },
      { name: "height", type: "decimal" },
      { name: "weight", type: "decimal" },
      { name: "emergency_contact", type: "text" },
      { name: "notes", type: "text" },
      { name: "trainer_id", type: "integer", references: { table: "trainers", column: "id" } }
    ];

    for (const col of columns) {
      const hasColumn = await db.schema.hasColumn("members", col.name);
      if (!hasColumn) {
        await db.schema.table("members", (table) => {
          if (col.type === "string") table.string(col.name);
          if (col.type === "decimal") table.decimal(col.name);
          if (col.type === "text") table.text(col.name);
          if (col.type === "integer") {
             const t = table.integer(col.name);
             if (col.references) t.references(col.references.column).inTable(col.references.table);
          }
        });
      }
    }
  }

  const hasInventory = await db.schema.hasTable("inventory");
  if (!hasInventory) {
    await db.schema.createTable("inventory", (table) => {
      table.increments("id").primary();
      table.string("name").notNullable();
      table.string("category");
      table.decimal("price").notNullable();
      table.integer("stock").defaultTo(0);
      table.integer("min_stock").defaultTo(5);
      table.string("sku").unique();
      table.timestamps(true, true);
    });
  }

  const hasSales = await db.schema.hasTable("sales");
  if (!hasSales) {
    await db.schema.createTable("sales", (table) => {
      table.increments("id").primary();
      table.integer("member_id").references("id").inTable("members").nullable();
      table.decimal("total_amount").notNullable();
      table.string("payment_method");
      table.timestamp("sale_date").defaultTo(db.fn.now());
      table.timestamps(true, true);
    });
  }

  const hasSaleItems = await db.schema.hasTable("sale_items");
  if (!hasSaleItems) {
    await db.schema.createTable("sale_items", (table) => {
      table.increments("id").primary();
      table.integer("sale_id").references("id").inTable("sales");
      table.integer("product_id").references("id").inTable("inventory");
      table.integer("quantity").notNullable();
      table.decimal("unit_price").notNullable();
    });
  }

  const hasSettings = await db.schema.hasTable("system_settings");
  if (!hasSettings) {
    await db.schema.createTable("system_settings", (table) => {
      table.string("key").primary();
      table.text("value");
      table.timestamps(true, true);
    });
    
    // Default settings
    await db("system_settings").insert([
      { key: "gym_name", value: "Titan Gym" },
      { key: "currency", value: "USD" },
      { key: "theme", value: "light" },
      { key: "address", value: "123 Fitness Ave, NY" }
    ]);
  }

  const hasAttendance = await db.schema.hasTable("attendance");
  if (!hasAttendance) {
    await db.schema.createTable("attendance", (table) => {
      table.increments("id").primary();
      table.integer("member_id").references("id").inTable("members");
      table.timestamp("check_in").defaultTo(db.fn.now());
      table.timestamp("check_out");
      table.date("date").notNullable();
      table.timestamps(true, true);
    });
  }

  const hasPayments = await db.schema.hasTable("payments");
  if (!hasPayments) {
    await db.schema.createTable("payments", (table) => {
      table.increments("id").primary();
      table.integer("member_id").references("id").inTable("members");
      table.decimal("amount").notNullable();
      table.string("payment_method");
      table.string("invoice_number").unique();
      table.timestamp("payment_date").defaultTo(db.fn.now());
      table.string("status").defaultTo("paid");
      table.timestamps(true, true);
    });
  }

  const hasTrainers = await db.schema.hasTable("trainers");
  if (!hasTrainers) {
    await db.schema.createTable("trainers", (table) => {
      table.increments("id").primary();
      table.string("name").notNullable();
      table.string("email").unique();
      table.string("phone");
      table.string("specialization");
      table.decimal("salary").defaultTo(0);
      table.text("bio");
      table.boolean("is_active").defaultTo(true);
      table.timestamps(true, true);
    });
  }

  const hasWorkouts = await db.schema.hasTable("workout_plans");
  if (!hasWorkouts) {
    await db.schema.createTable("workout_plans", (table) => {
      table.increments("id").primary();
      table.integer("member_id").references("id").inTable("members");
      table.string("title").notNullable();
      table.text("description");
      table.json("exercises"); // Array of {name, sets, reps, weight}
      table.timestamps(true, true);
    });
  }

  const hasDiet = await db.schema.hasTable("diet_plans");
  if (!hasDiet) {
    await db.schema.createTable("diet_plans", (table) => {
      table.increments("id").primary();
      table.integer("member_id").references("id").inTable("members");
      table.string("title").notNullable();
      table.text("meals"); // JSON or text
      table.timestamps(true, true);
    });
  }

  const hasExpenses = await db.schema.hasTable("expenses");
  if (!hasExpenses) {
    await db.schema.createTable("expenses", (table) => {
      table.increments("id").primary();
      table.string("category").notNullable();
      table.decimal("amount").notNullable();
      table.string("description");
      table.date("date").notNullable();
      table.timestamps(true, true);
    });
  }
}

export default db;
