import db from "./src/lib/db.ts";
async function check() {
  const users = await db("users").select("email", "password");
  console.log(JSON.stringify(users, null, 2));
  process.exit(0);
}
check();
