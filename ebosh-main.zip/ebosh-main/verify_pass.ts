import bcrypt from "bcryptjs";
async function check() {
  const hash = "$2b$10$0tjYoCyxJ.qPK8wYtmrG9Om7n5hx6THK0BdtyP2T0fJKHR63Efhmi";
  const isValid = await bcrypt.compare("admin123", hash);
  console.log("Is admin123 valid?", isValid);
  const isValidAdmin = await bcrypt.compare("admin", hash);
  console.log("Is admin valid?", isValidAdmin);
}
check();
