import db from "./src/lib/db.ts";
import bcrypt from "bcryptjs";
async function fix() {
  const hashedPassword = await bcrypt.hash("admin123", 10);
  await db("users").where({ email: "admin@titangym.com" }).update({
    password: hashedPassword
  });
  console.log("Password updated to admin123 for admin@titangym.com");
  process.exit(0);
}
fix();
